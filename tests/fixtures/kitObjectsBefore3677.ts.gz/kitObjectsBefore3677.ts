import * as THREE from 'three';
import { surfaceMaterial, enableAO, getDetailLevel, setDetailLevel, mergeGeometries, type SurfaceKind, type Detail } from './surfaces';

// The detail tier lives in surfaces.ts so the ground reads the same setting as the objects; it is
// re-exported here so `import { setDetailLevel } from './objects'` keeps working everywhere.
export { setDetailLevel, getDetailLevel };
export type { Detail };

interface BaseOpts { detail?: Detail; seed?: number }
const tier = (o?: BaseOpts): Detail => o?.detail ?? getDetailLevel();

function rng(seed: number): () => number {
  let t = (seed >>> 0) || 1;
  return () => {
    t += 0x6d2b79f5;
    let x = Math.imul(t ^ (t >>> 15), 1 | t);
    x ^= x + Math.imul(x ^ (x >>> 7), 61 | x);
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}

/** Shared per-kind materials — a hundred trees must not build a hundred bark materials. */
const matCache = new Map<string, THREE.Material>();
function shared(kind: SurfaceKind, detail: Detail, color?: number, repeat = 3): THREE.Material {
  const key = kind + ':' + detail + ':' + (color ?? 'x') + ':' + repeat;
  let m = matCache.get(key);
  if (!m) {
    m = detail === 'real'
      ? surfaceMaterial(kind, { color, repeat })
      // The light tier deliberately skips the texture maps: on a phone the generation cost and the
      // texture memory are the whole budget, and a plain colour is what "just 3D" asked for.
      : new THREE.MeshStandardMaterial({ color: color ?? 0x9aa0a6, roughness: 0.85, metalness: kind === 'metal' ? 1 : 0 });
    matCache.set(key, m);
  }
  return m;
}
export function disposeObjectMaterials(): void {
  for (const m of matCache.values()) m.dispose();
  matCache.clear();
}

function mesh(geo: THREE.BufferGeometry, mat: THREE.Material, detail: Detail): THREE.Mesh {
  if (detail === 'real') enableAO(geo);
  const m = new THREE.Mesh(geo, mat);
  m.castShadow = true;
  m.receiveShadow = true;
  return m;
}

// ── VEHICLE PARTS — one implementation every vehicle shares ──────────────────────────────────────
// The car grew these first; the rickshaw, bus, truck and tractor use the SAME ones, so a fix to a wheel
// or a body is a fix to every vehicle (four private copies is how a bug gets fixed in one of them).

/** A closed outline from (z, y) points. */
function outlineShape(pts: number[][]): THREE.Shape {
  const sh = new THREE.Shape();
  sh.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) sh.lineTo(pts[i][0], pts[i][1]);
  sh.closePath();
  return sh;
}

/**
 * A side profile drawn in (z = length, y = height), front at +z, extruded across the width with a rounded
 * bevel. This is how every vehicle body here is made — the outline IS the vehicle, never a box on a box.
 */
function extrudeProfile(pts: number[][], width: number, bevel: number, real: boolean): THREE.BufferGeometry {
  const depth = Math.max(0.01, width - 2 * bevel);
  const g = new THREE.ExtrudeGeometry(outlineShape(pts), {
    depth, bevelEnabled: bevel > 0, bevelThickness: bevel, bevelSize: bevel,
    bevelSegments: real ? 4 : 1, curveSegments: 1,
  });
  g.translate(0, 0, -depth / 2);
  g.rotateY(-Math.PI / 2);          // profile z → model +Z (the front), extrusion → model X
  g.computeVertexNormals();
  return g;
}

/**
 * The arch of a wheel well cut into a sill at height `sill`, over a wheel of radius `wheelR` at z = cz.
 * Points run rear foot → over the top → front foot, so a profile drawn along its bottom from the back to
 * the front simply includes them in order.
 */
function wellArc(cz: number, wheelR: number, sill: number, wellR: number, real: boolean): number[][] {
  const a = Math.asin(Math.max(-1, Math.min(1, (wheelR - sill) / wellR)));
  const out: number[][] = [];
  const n = real ? 14 : 6;
  for (let i = 0; i <= n; i++) {
    const t = Math.PI + a - ((Math.PI + 2 * a) * i) / n;
    out.push([cz + Math.cos(t) * wellR, wheelR + Math.sin(t) * wellR]);
  }
  return out;
}

interface WheelMaterials { tyre: THREE.Material; rim: THREE.Material; rimInner: THREE.Material }

/**
 * A road wheel, as a group named 'wheel' — rollWheels() and driveVehicle() spin exactly those. A tyre
 * lathed from its rounded cross-section, a rim, and at the real tier a spoked face on the OUTER side
 * (`side` = +1 for a wheel on the +X side) so a rolling wheel visibly turns. Never a torus inside it:
 * that is what the old floating arch was, and the arch test keeps wheel groups free of them.
 */
function roadWheel(radius: number, width: number, side: number, d: Detail, mats: WheelMaterials, spokes = 5): THREE.Group {
  const real = d === 'real';
  const r = radius, h = width / 2;
  const k = r / 0.3225;              // the car's wheel is the reference size for the small parts
  const seg = real ? 28 : 12;
  const rimR = r * 0.64;
  const wheel = new THREE.Group();
  const profile = [[rimR, -h], [r * 0.9, -h], [r * 0.97, -h * 0.86], [r, -h * 0.55], [r, h * 0.55],
    [r * 0.97, h * 0.86], [r * 0.9, h], [rimR, h], [rimR, -h]].map(([a, b]) => new THREE.Vector2(a, b));
  const tyre = mesh(new THREE.LatheGeometry(profile, seg), mats.tyre, d);
  tyre.rotation.z = Math.PI / 2;
  wheel.add(tyre);
  const rim = mesh(new THREE.CylinderGeometry(rimR, rimR, width * 0.8, seg), real ? mats.rimInner : mats.rim, d);
  rim.rotation.z = Math.PI / 2;
  wheel.add(rim);
  if (real) {
    const face = side * width * 0.42;
    const faceParts: THREE.Mesh[] = [];
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(rimR * 0.28, rimR * 0.28, 0.03 * k, 12));
    hub.rotation.z = Math.PI / 2;
    hub.position.x = face;
    faceParts.push(hub);
    const lip = new THREE.Mesh(new THREE.RingGeometry(rimR * 0.84, rimR, seg));
    lip.rotation.y = (side * Math.PI) / 2;
    lip.position.x = face + side * 0.012 * k;
    faceParts.push(lip);
    for (let i = 0; i < spokes; i++) {
      const a = (i / spokes) * Math.PI * 2;
      const spoke = new THREE.Mesh(new THREE.BoxGeometry(0.03 * k, rimR * 0.8, 0.045 * k));
      spoke.position.set(face, Math.cos(a) * rimR * 0.5, Math.sin(a) * rimR * 0.5);
      spoke.rotation.x = a;
      faceParts.push(spoke);
    }
    wheel.add(mesh(mergeGeometries(faceParts), mats.rim, d));
  }
  wheel.name = 'wheel';
  return wheel;
}

/** Paint that reads as paint: clearcoat at the real tier, plain at lite. */
function vehiclePaint(color: number, d: Detail): THREE.Material {
  return d === 'real'
    ? new THREE.MeshPhysicalMaterial({ color, roughness: 0.32, metalness: 0.6, clearcoat: 1, clearcoatRoughness: 0.1 })
    : new THREE.MeshStandardMaterial({ color, roughness: 0.5, metalness: 0.25 });
}

function vehicleGlass(d: Detail): THREE.Material {
  return d === 'real'
    ? new THREE.MeshPhysicalMaterial({ color: 0x0b0f13, roughness: 0.04, metalness: 0.2, clearcoat: 1, clearcoatRoughness: 0.02 })
    : new THREE.MeshStandardMaterial({ color: 0x10151a, roughness: 0.2, metalness: 0.3 });
}

/** A posed box, for baking small parts into one mesh (one draw call per material). */
function partBox(w: number, h: number, dd: number, x: number, y: number, z: number, rx = 0, ry = 0, rz = 0): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, dd));
  m.position.set(x, y, z);
  m.rotation.set(rx, ry, rz);
  return m;
}

/** A posed cylinder along Y (a post, a stack), for baking. */
function partRod(r: number, len: number, x: number, y: number, z: number, rx = 0, rz = 0, seg = 8): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, seg));
  m.position.set(x, y, z);
  m.rotation.set(rx, 0, rz);
  return m;
}

/** A lamp that EMITS. An unlit "light" is a coloured sticker. */
function lamp(color: number, w: number, h: number, x: number, y: number, z: number): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, 0.03), new THREE.MeshBasicMaterial({ color }));
  m.position.set(x, y, z);
  return m;
}

// ── CAR ──────────────────────────────────────────────────────────────────────────────────────────
export interface CarOptions extends BaseOpts { color?: number; length?: number }

/**
 * A car built from its real silhouette, at real proportions: ~4.3 m long, 1.8 m wide, 1.45 m tall,
 * 2.6 m wheelbase, 0.32 m wheel radius. Those five numbers are most of why it reads as a car.
 *
 * 🔒 THE BODY IS A PROFILE, NOT BOXES (admin 2026-10-05, Phase 2: "if the player vehicle still looks like
 * a box: FAIL"). The side outline — nose, bonnet, raked windscreen, curved roof, backlight, boot, and the
 * two wheel wells cut out of the sill — is drawn once and extruded across the width with a rounded bevel.
 * Both tiers get that shape; `real` adds what you only notice up close: door seams and handles, spoked
 * rims, grilles, a plate, dark well liners, clearcoat paint. Locked by tests/aHeroObjectIsNotABox.test.ts.
 */
export function createCar(options: CarOptions = {}): THREE.Group {
  const d = tier(options);
  const L = options.length ?? 4.3;
  const s = L / 4.3;                 // every number below is metres on a 4.3 m saloon, scaled by s
  const W = L * 0.42;
  const paint = options.color ?? 0xb42b2b;
  const real = d === 'real';
  const group = new THREE.Group();

  const bodyMat = real
    ? new THREE.MeshPhysicalMaterial({ color: paint, roughness: 0.28, metalness: 0.85, clearcoat: 1, clearcoatRoughness: 0.08 })
    : new THREE.MeshStandardMaterial({ color: paint, roughness: 0.5, metalness: 0.3 });
  // Glass is DARK and REFLECTIVE, not see-through: the greenhouse is a solid volume, so transmission
  // would show the sky through the whole cabin and read as a glass brick.
  const glassMat = real
    ? new THREE.MeshPhysicalMaterial({ color: 0x0b0f13, roughness: 0.04, metalness: 0.2, clearcoat: 1, clearcoatRoughness: 0.02 })
    : new THREE.MeshStandardMaterial({ color: 0x10151a, roughness: 0.2, metalness: 0.3 });
  const trimMat = new THREE.MeshStandardMaterial({ color: 0x15181c, roughness: 0.6, metalness: 0.5 });
  const tyreMat = shared('fabric', d, 0x14161a, 2);
  const rimMat = new THREE.MeshStandardMaterial({ color: 0xc6ccd4, roughness: 0.25, metalness: 1 });

  const wheelR = L * 0.075;
  const axleZ = 1.3 * s;             // 2.6 m wheelbase
  const wellR = 0.41 * s;            // the cut-out the tyre sits in, a little larger than the tyre
  const sill = 0.2 * s;              // ground clearance under the doors

  // A side profile is the car. It is drawn in (z = length, y = height), front at +z, then extruded
  // across the width with a bevel so every edge is rounded — never a box with a box on top.
  const scaled = (pts: number[][]) => pts.map(([z, y]) => [z * s, y * s]);
  const extrudeAcross = (pts: number[][], width: number, bevel: number) => extrudeProfile(pts, width, bevel, real);

  // Body: nose, bonnet, shoulder line, boot deck, tail — with the two wheel wells cut out of the sill.
  const bodyPts = [
    ...scaled([[2.02, 0.22], [2.12, 0.3], [2.16, 0.42], [2.15, 0.56], [2.1, 0.66], [1.98, 0.74],
      [1.6, 0.8], [1.2, 0.85], [0.92, 0.88], [0, 0.9], [-1, 0.93], [-1.5, 0.95], [-1.85, 0.96],
      [-2.05, 0.93], [-2.13, 0.86], [-2.17, 0.72], [-2.17, 0.5], [-2.12, 0.32], [-2.04, 0.22]]),
    ...wellArc(-axleZ, wheelR, sill, wellR, real),
    ...wellArc(axleZ, wheelR, sill, wellR, real),
  ];
  const bodyBevel = 0.05 * s;
  group.add(mesh(extrudeAcross(bodyPts, W, bodyBevel), bodyMat, d));

  // Greenhouse: raked windscreen, curved roof, sloping backlight — narrower than the body, so the
  // glass sits on a shoulder the way it does on every real car.
  const Wg = W * 0.8;
  const glassBevel = 0.06 * s;
  group.add(mesh(extrudeAcross(scaled([[0.98, 0.86], [0.12, 1.36], [-0.1, 1.41], [-0.5, 1.43], [-0.9, 1.4],
    [-1.05, 1.36], [-1.62, 0.92], [-1.6, 0.86]]), Wg, glassBevel), glassMat, d));
  // Roof skin in paint over the top of the glass.
  group.add(mesh(extrudeAcross(scaled([[0.16, 1.3], [0.16, 1.33], [0.1, 1.375], [-0.1, 1.425], [-0.5, 1.445],
    [-0.9, 1.415], [-1.07, 1.355], [-1.07, 1.3]]), Wg + 0.02 * s, glassBevel), bodyMat, d));

  // Small parts that share a material are BAKED into one mesh per material: a car of 70 separate
  // meshes is 70 draw calls, and ten of them in a scene is what makes a mid-range phone stutter.
  const paintParts: THREE.Mesh[] = [];
  const trimParts: THREE.Mesh[] = [];
  const chromeParts: THREE.Mesh[] = [];
  const box = (w: number, h: number, dd: number, x: number, y: number, z: number, rx = 0) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, dd));
    m.position.set(x, y, z);
    m.rotation.x = rx;
    return m;
  };
  // A thin box laid along a line of the profile, on one side of the car.
  const strut = (z0: number, y0: number, z1: number, y1: number, x: number, thick: number) => {
    const dz = (z1 - z0) * s, dy = (y1 - y0) * s;
    return box(0.09 * s, thick * s, Math.hypot(dz, dy), x, ((y0 + y1) / 2) * s, ((z0 + z1) / 2) * s, Math.atan2(-dy, dz));
  };
  // A pillar WRAPS the greenhouse's rounded corner (0.09 m deep, its outer face just proud of the side
  // glass). A thin strip on the side face left the curved glass beside it, so it read as a loose fin.
  const glassSide = Wg / 2 + glassBevel - 0.042 * s;
  const bodySide = W / 2;
  for (const side of [-1, 1]) {
    // Pillars frame the glass into a windscreen, side windows and a backlight.
    paintParts.push(strut(0.98, 0.88, 0.2, 1.32, side * glassSide, 0.07));
    paintParts.push(strut(-0.3, 0.9, -0.34, 1.37, side * glassSide, 0.09));
    paintParts.push(strut(-1.02, 1.32, -1.56, 0.95, side * glassSide, 0.1));
    // Wing mirror on a stalk, at the front of the door.
    paintParts.push(box(0.1 * s, 0.09 * s, 0.17 * s, side * (bodySide + 0.09 * s), 1.0 * s, 0.8 * s));
    trimParts.push(box(0.1 * s, 0.03 * s, 0.05 * s, side * (bodySide + 0.03 * s), 0.96 * s, 0.82 * s));
    // Black sill between the wheels.
    trimParts.push(box(0.03 * s, 0.09 * s, 1.75 * s, side * (bodySide + 0.01 * s), 0.25 * s, 0));
    if (real) {
      // Door shut-lines and handles: what makes a painted surface read as a door.
      for (const [z, y0, y1] of [[0.93, 0.62, 0.9], [-0.3, 0.3, 0.92], [-1.04, 0.74, 0.95]]) {
        trimParts.push(box(0.006 * s, (y1 - y0) * s, 0.014 * s, side * (bodySide + 0.002 * s), ((y0 + y1) / 2) * s, z * s));
      }
      for (const z of [0.15, -0.95]) chromeParts.push(box(0.025 * s, 0.03 * s, 0.16 * s, side * (bodySide + 0.012 * s), 0.8 * s, z * s));
    }
  }
  if (real) {
    // Grilles and diffuser: dark breaks that stop the nose and tail reading as a slab.
    trimParts.push(box(W * 0.56, 0.13 * s, 0.03 * s, 0, 0.4 * s, 2.215 * s));
    trimParts.push(box(W * 0.36, 0.07 * s, 0.03 * s, 0, 0.6 * s, 2.19 * s));
    trimParts.push(box(W * 0.7, 0.1 * s, 0.03 * s, 0, 0.29 * s, -2.21 * s));
    const plate = mesh(new THREE.BoxGeometry(0.52 * s, 0.11 * s, 0.03 * s), new THREE.MeshStandardMaterial({ color: 0xe8e6df, roughness: 0.6 }), d);
    plate.position.set(0, 0.52 * s, -2.225 * s);
    group.add(plate);
  }
  group.add(mesh(mergeGeometries(paintParts), bodyMat, d));
  group.add(mesh(mergeGeometries(trimParts), trimMat, d));
  if (chromeParts.length) group.add(mesh(mergeGeometries(chromeParts), rimMat, d));

  // Lights that EMIT, laid on the nose and tail surfaces. An unlit "light" is a coloured sticker.
  for (const side of [-1, 1]) {
    const head = new THREE.Mesh(new THREE.BoxGeometry(W * 0.24, 0.12 * s, 0.025 * s), new THREE.MeshBasicMaterial({ color: 0xfff3d0 }));
    head.position.set(side * W * 0.31, 0.722 * s, 2.098 * s);
    head.rotation.x = -0.985;
    group.add(head);
    const tail = new THREE.Mesh(new THREE.BoxGeometry(W * 0.27, 0.09 * s, 0.025 * s), new THREE.MeshBasicMaterial({ color: 0xd82b1e }));
    tail.position.set(side * W * 0.3, 0.8 * s, -2.215 * s);
    group.add(tail);
  }

  // Wheels: a rounded tyre on a spoked rim (roadWheel, shared by every vehicle), sitting IN the wells.
  const tyreW = 0.22 * s;
  const linerMat = new THREE.MeshStandardMaterial({ color: 0x0b0c0e, roughness: 0.95, side: THREE.DoubleSide });
  for (const sx of [-1, 1]) {
    for (const sz of [1, -1]) {
      const wheel = roadWheel(wheelR, tyreW, sx, d, { tyre: tyreMat, rim: rimMat, rimInner: trimMat });
      const h = tyreW / 2;
      if (real) {
        // 🔴 THE ARCH BELONGS TO THE BODY, NOT THE WHEEL (a child of the wheel group spun with it and,
        // offset twice, floated a car-width outside the body). It is the dark liner of the wheel well,
        // fixed to the body over the wheel's own centre, so the well reads as a hole, not painted metal.
        // Its radius is the well's AFTER the body bevel (the bevel grows the outline into the well).
        const linerR = wellR - bodyBevel - 0.01 * s;
        const arch = mesh(new THREE.CylinderGeometry(linerR, linerR, 0.5 * s, 18, 1, true, -0.35, Math.PI + 0.7), linerMat, d);
        arch.rotation.z = Math.PI / 2;
        arch.position.set(sx * (bodySide - 0.25 * s), wheelR, sz * axleZ);
        arch.name = 'wheel-arch';
        group.add(arch);
      }
      wheel.position.set(sx * (bodySide - h - 0.01 * s), wheelR, sz * axleZ);
      group.add(wheel);
    }
  }
  return group;
}

/** Spin the wheels. Call with the car's speed each frame — still wheels on a moving car is the tell. */
export function rollWheels(car: THREE.Group, speed: number, dt: number): void {
  for (const child of car.children) {
    if (child.name === 'wheel') child.rotation.x += speed * dt * 3.2;
  }
}

// ── INDIA'S ROADS: AUTO-RICKSHAW, BUS, TRUCK, TRACTOR ────────────────────────────────────────────
// The object catalogue described all four (objectCatalog.ts: dimensions, parts, the one "tell" that makes
// each read as itself) but had no builder for any of them, so a game asked for an auto or a bus got
// whatever the model improvised — the box-with-wheels the admin's Phase 2 brief calls a FAIL. Each is
// built here from its own side profile at its real size, with the shared wheel and body helpers above,
// faces +Z like every model, and rolls with rollWheels() / driveVehicle().

export interface AutoRickshawOptions extends BaseOpts {
  /** Delhi CNG green-and-yellow, or Mumbai black-and-yellow. */
  livery?: 'delhi' | 'mumbai';
  color?: number;
  length?: number;
}

/**
 * An auto-rickshaw: 2.6 m long, 1.3 m wide, 1.7 m tall, THREE wheels (one front under the cowl, two at
 * the back), handlebar steering, a canvas roof on thin posts — and OPEN sides, so you can see straight
 * through it. That see-through stance is what no car has, and it is the whole silhouette.
 */
export function createAutoRickshaw(options: AutoRickshawOptions = {}): THREE.Group {
  const d = tier(options);
  const real = d === 'real';
  const s = (options.length ?? 2.6) / 2.6;
  const mumbai = options.livery === 'mumbai';
  const body = vehiclePaint(options.color ?? (mumbai ? 0x1b1b1b : 0x1f8f3c), d);
  const canopyMat = new THREE.MeshStandardMaterial({ color: mumbai ? 0xf2c230 : 0xf5c518, roughness: 0.9, metalness: 0, side: THREE.DoubleSide });
  const seatMat = new THREE.MeshStandardMaterial({ color: 0x23201d, roughness: 0.7, metalness: 0.05 });
  const trim = new THREE.MeshStandardMaterial({ color: 0x1a1c1f, roughness: 0.5, metalness: 0.6 });
  const chrome = new THREE.MeshStandardMaterial({ color: 0xc6ccd4, roughness: 0.25, metalness: 1 });
  const wm = { tyre: shared('fabric', d, 0x14161a, 2), rim: chrome, rimInner: trim };
  const g = new THREE.Group();
  const sc = (pts: number[][]) => pts.map(([z, y]) => [z * s, y * s]);
  const r = 0.2 * s, sill = 0.28 * s;
  const frontZ = 0.95 * s, rearZ = -0.75 * s, rearX = 0.55 * s;

  // The driver's cowl — narrow, with the front wheel under it and the dashboard on top.
  g.add(mesh(extrudeProfile([
    ...sc([[0.62, 0.3]]), ...wellArc(frontZ, r, sill, 0.26 * s, real),
    ...sc([[1.3, 0.3], [1.34, 0.56], [1.28, 0.96], [1.1, 1.04], [0.92, 1.0], [0.84, 0.62], [0.66, 0.56]]),
  ], 0.78 * s, 0.05 * s, real), body, d));
  // The floor and the passengers' tub, full width, with the rear wheel wells in its sill.
  g.add(mesh(extrudeProfile([
    ...sc([[-1.25, 0.28]]), ...wellArc(rearZ, r, sill, 0.27 * s, real),
    ...sc([[0.75, 0.28], [0.75, 0.42], [-0.4, 0.42], [-0.46, 0.78], [-1.16, 0.82], [-1.27, 1.05], [-1.33, 1.0], [-1.33, 0.36]]),
  ], 1.3 * s, 0.05 * s, real), body, d));
  // The canvas roof, curved, dropping down at the back like the real drape.
  g.add(mesh(extrudeProfile(sc([
    [1.08, 1.55], [1.0, 1.66], [0.5, 1.72], [-0.5, 1.72], [-1.1, 1.68], [-1.33, 1.5], [-1.36, 1.05],
    [-1.3, 1.05], [-1.27, 1.48], [-1.06, 1.63], [-0.5, 1.67], [0.5, 1.67], [0.98, 1.61], [1.03, 1.53],
  ]), 1.36 * s, 0.03 * s, real), canopyMat, d));

  // Posts, handlebar and the seats' frames — baked, one draw call.
  const metal: THREE.Mesh[] = [
    partRod(0.018 * s, 0.62 * s, 0.5 * s, 1.3 * s, 1.0 * s), partRod(0.018 * s, 0.62 * s, -0.5 * s, 1.3 * s, 1.0 * s),
    partRod(0.02 * s, 0.9 * s, 0.63 * s, 1.24 * s, -0.42 * s), partRod(0.02 * s, 0.9 * s, -0.63 * s, 1.24 * s, -0.42 * s),
    partRod(0.016 * s, 0.62 * s, 0, 1.08 * s, 0.82 * s, 0, Math.PI / 2),           // the handlebar
    partRod(0.03 * s, 0.32 * s, 0, 0.92 * s, 0.86 * s, -0.5),                       // its column
  ];
  g.add(mesh(mergeGeometries(metal), trim, d));
  g.add(mesh(mergeGeometries([
    partBox(0.46 * s, 0.12 * s, 0.36 * s, 0, 0.62 * s, 0.32 * s),                  // driver's seat
    partBox(0.3 * s, 0.18 * s, 0.3 * s, 0, 0.5 * s, 0.32 * s),
    partBox(1.12 * s, 0.14 * s, 0.46 * s, 0, 0.88 * s, -0.86 * s),                 // passengers' bench
    partBox(1.12 * s, 0.42 * s, 0.1 * s, 0, 1.12 * s, -1.16 * s, -0.12),
  ]), seatMat, d));
  const glass = mesh(new THREE.BoxGeometry(0.86 * s, 0.52 * s, 0.025 * s), vehicleGlass(d), d);
  glass.position.set(0, 1.27 * s, 1.02 * s);
  glass.rotation.x = -0.16;
  g.add(glass);
  if (real) {
    // Grips and mirrors: the details you only see up close.
    g.add(mesh(mergeGeometries([
      partRod(0.024 * s, 0.1 * s, 0.32 * s, 1.08 * s, 0.82 * s, 0, Math.PI / 2), partRod(0.024 * s, 0.1 * s, -0.32 * s, 1.08 * s, 0.82 * s, 0, Math.PI / 2),
      partBox(0.12 * s, 0.07 * s, 0.03 * s, 0.46 * s, 1.36 * s, 1.03 * s), partBox(0.12 * s, 0.07 * s, 0.03 * s, -0.46 * s, 1.36 * s, 1.03 * s),
    ]), seatMat, d));
  }
  g.add(lamp(0xfff3d0, 0.16 * s, 0.12 * s, 0, 0.84 * s, 1.36 * s));
  g.add(lamp(0xd82b1e, 0.14 * s, 0.08 * s, 0.5 * s, 0.62 * s, -1.37 * s));
  g.add(lamp(0xd82b1e, 0.14 * s, 0.08 * s, -0.5 * s, 0.62 * s, -1.37 * s));

  const front = roadWheel(r, 0.12 * s, 1, d, wm);
  front.position.set(0, r, frontZ);
  g.add(front);
  for (const sx of [-1, 1]) {
    const w = roadWheel(r, 0.13 * s, sx, d, wm);
    w.position.set(sx * rearX, r, rearZ);
    g.add(w);
  }
  return g;
}

export interface BusOptions extends BaseOpts { color?: number; stripe?: number; length?: number }

/**
 * A bus: 11 m long, 2.5 m wide, 3.2 m tall, 5.6 m wheelbase, 0.5 m wheels (dual at the back). The
 * window band running the whole length at one height is what makes it a bus rather than a large van; the
 * lit destination board and the doors on the KERB side (the driver's left, +X — India drives on the left)
 * make it a working one.
 */
export function createBus(options: BusOptions = {}): THREE.Group {
  const d = tier(options);
  const real = d === 'real';
  const s = (options.length ?? 11) / 11;
  const W = 2.5 * s;
  const paint = vehiclePaint(options.color ?? 0xc62828, d);
  const stripeMat = new THREE.MeshStandardMaterial({ color: options.stripe ?? 0xf4efe1, roughness: 0.5 });
  const glassMat = vehicleGlass(d);
  const trim = new THREE.MeshStandardMaterial({ color: 0x15181c, roughness: 0.6, metalness: 0.5 });
  const chrome = new THREE.MeshStandardMaterial({ color: 0xc6ccd4, roughness: 0.25, metalness: 1 });
  const wm = { tyre: shared('fabric', d, 0x14161a, 2), rim: chrome, rimInner: trim };
  const g = new THREE.Group();
  const sc = (pts: number[][]) => pts.map(([z, y]) => [z * s, y * s]);
  const r = 0.5 * s, sill = 0.36 * s, wellR = 0.6 * s;
  const frontAxle = 3.2 * s, rearAxle = -2.4 * s;

  g.add(mesh(extrudeProfile([
    ...sc([[-5.4, 0.36]]), ...wellArc(rearAxle, r, sill, wellR, real), ...wellArc(frontAxle, r, sill, wellR, real),
    ...sc([[5.42, 0.36], [5.5, 0.6], [5.52, 1.4], [5.46, 2.95], [5.3, 3.16], [-5.3, 3.16], [-5.46, 3.0], [-5.5, 0.55]]),
  ], W, 0.08 * s, real), paint, d));

  // The window band down both sides, the pillars that divide it, and a stripe under it.
  const side = W / 2 + 0.008 * s;
  const glassParts: THREE.Mesh[] = [];
  const pillarParts: THREE.Mesh[] = [];
  const stripeParts: THREE.Mesh[] = [];
  for (const sx of [-1, 1]) {
    glassParts.push(partBox(0.02 * s, 1.0 * s, 9.6 * s, sx * side, 2.1 * s, -0.15 * s));
    stripeParts.push(partBox(0.02 * s, 0.16 * s, 10.7 * s, sx * (side + 0.004 * s), 1.42 * s, 0));
    for (let z = -4.8; z <= 4.6; z += 1.34) pillarParts.push(partBox(0.03 * s, 1.02 * s, 0.1 * s, sx * (side + 0.008 * s), 2.1 * s, z * s));
  }
  // Windscreen and back window.
  glassParts.push(partBox(W * 0.86, 1.3 * s, 0.03 * s, 0, 2.05 * s, 5.53 * s, -0.04));
  glassParts.push(partBox(W * 0.8, 0.8 * s, 0.03 * s, 0, 2.3 * s, -5.52 * s));
  // Doors on the kerb side (+X): dark glass panels, front and middle.
  for (const z of [4.1, -0.8]) glassParts.push(partBox(0.025 * s, 2.3 * s, 1.0 * s, side + 0.006 * s, 1.55 * s, z * s));
  g.add(mesh(mergeGeometries(glassParts), glassMat, d));
  g.add(mesh(mergeGeometries(pillarParts), paint, d));
  g.add(mesh(mergeGeometries(stripeParts), stripeMat, d));
  const trimParts = [
    partBox(W * 1.02, 0.34 * s, 0.12 * s, 0, 0.55 * s, 5.5 * s), partBox(W * 1.02, 0.34 * s, 0.12 * s, 0, 0.55 * s, -5.5 * s),
    partBox(0.04 * s, 0.14 * s, 9.6 * s, side, 0.42 * s, 0), partBox(0.04 * s, 0.14 * s, 9.6 * s, -side, 0.42 * s, 0),
  ];
  if (real) {
    // Wipers, mirrors on stalks, a roof hatch line.
    trimParts.push(partBox(0.04 * s, 0.7 * s, 0.03 * s, 0.4 * s, 1.75 * s, 5.56 * s, 0, 0, 0.5), partBox(0.04 * s, 0.7 * s, 0.03 * s, -0.4 * s, 1.75 * s, 5.56 * s, 0, 0, 0.5));
    for (const sx of [-1, 1]) {
      // Mirrors reach about a quarter-metre past the body, as on a real bus — not half a metre.
      trimParts.push(partBox(0.26 * s, 0.05 * s, 0.05 * s, sx * (W / 2 + 0.1 * s), 2.75 * s, 5.35 * s));
      trimParts.push(partBox(0.06 * s, 0.38 * s, 0.2 * s, sx * (W / 2 + 0.22 * s), 2.5 * s, 5.35 * s));
    }
  }
  g.add(mesh(mergeGeometries(trimParts), trim, d));
  // The destination board is LIT — it is a screen, not paint.
  g.add(lamp(0xffb300, W * 0.7, 0.28 * s, 0, 2.86 * s, 5.55 * s));
  for (const sx of [-1, 1]) {
    g.add(lamp(0xfff3d0, 0.32 * s, 0.18 * s, sx * W * 0.36, 0.86 * s, 5.55 * s));
    g.add(lamp(0xd82b1e, 0.22 * s, 0.4 * s, sx * W * 0.4, 1.0 * s, -5.55 * s));
  }

  const tw = 0.3 * s;
  for (const sx of [-1, 1]) {
    const f = roadWheel(r, tw, sx, d, wm, 8);
    f.position.set(sx * (W / 2 - tw / 2 - 0.03 * s), r, frontAxle);
    g.add(f);
    // Dual rear wheels: an outer and an inner tyre on each side, the way every loaded bus runs.
    const outer = roadWheel(r, tw, sx, d, wm, 8);
    outer.position.set(sx * (W / 2 - tw / 2 - 0.03 * s), r, rearAxle);
    const inner = roadWheel(r, tw, sx, d, wm, 8);
    inner.position.set(sx * (W / 2 - tw * 1.55 - 0.03 * s), r, rearAxle);
    g.add(outer, inner);
  }
  return g;
}

export interface TruckOptions extends BaseOpts { color?: number; cargoColor?: number; length?: number }

/**
 * A truck: 8.5 m long, 2.5 m wide, 3.4 m tall, 0.52 m wheels, the rear ones doubled. The GAP between the
 * cab and the load body is the defining line — one continuous box is a bus. Dressed as India's trucks
 * are: a high wooden body painted in bands, a decorated crown over the cab, mudflaps and a tall stack.
 */
export function createTruck(options: TruckOptions = {}): THREE.Group {
  const d = tier(options);
  const real = d === 'real';
  const s = (options.length ?? 8.5) / 8.5;
  const W = 2.5 * s;
  const cab = vehiclePaint(options.color ?? 0xe65100, d);
  const cargo = new THREE.MeshStandardMaterial({ color: options.cargoColor ?? 0xf9a825, roughness: 0.75 });
  const bandMats = [0xc62828, 0x1565c0, 0x2e7d32].map((c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.7 }));
  const glassMat = vehicleGlass(d);
  const trim = new THREE.MeshStandardMaterial({ color: 0x15181c, roughness: 0.6, metalness: 0.5 });
  const chrome = new THREE.MeshStandardMaterial({ color: 0xc6ccd4, roughness: 0.25, metalness: 1 });
  const wm = { tyre: shared('fabric', d, 0x14161a, 2), rim: chrome, rimInner: trim };
  const g = new THREE.Group();
  const sc = (pts: number[][]) => pts.map(([z, y]) => [z * s, y * s]);
  const r = 0.52 * s, sill = 0.6 * s;
  const frontAxle = 3.3 * s, rearAxle = -2.2 * s;

  // The cab: tall, flat-nosed, the front wheels under it.
  g.add(mesh(extrudeProfile([
    ...sc([[2.6, 0.6]]), ...wellArc(frontAxle, r, sill, 0.62 * s, real),
    ...sc([[4.22, 0.6], [4.3, 1.2], [4.24, 2.75], [4.02, 3.05], [2.68, 3.1], [2.6, 2.9]]),
  ], W * 0.96, 0.08 * s, real), cab, d));
  g.add(mesh(mergeGeometries([
    partBox(W * 0.84, 0.86 * s, 0.03 * s, 0, 2.3 * s, 4.29 * s, -0.08),
    partBox(0.02 * s, 0.7 * s, 0.9 * s, W * 0.49, 2.35 * s, 3.55 * s), partBox(0.02 * s, 0.7 * s, 0.9 * s, -W * 0.49, 2.35 * s, 3.55 * s),
  ]), glassMat, d));

  // The load body: floor, sides, front wall and tailgate — a high wooden box, painted in bands — with
  // a gap behind the cab and a decorated crown arching over it.
  const top = 3.0 * s, floorY = 1.3 * s, z0 = 2.3 * s, z1 = -4.05 * s, len = z0 - z1, mid = (z0 + z1) / 2;
  const t = 0.09 * s;
  g.add(mesh(mergeGeometries([
    partBox(W, 0.14 * s, len, 0, floorY, mid),
    partBox(t, top - floorY, len, W / 2 - t / 2, (top + floorY) / 2, mid), partBox(t, top - floorY, len, -W / 2 + t / 2, (top + floorY) / 2, mid),
    partBox(W, top - floorY + 0.35 * s, t, 0, (top + 0.35 * s + floorY) / 2, z0),
    partBox(W, top - floorY, t, 0, (top + floorY) / 2, z1),
  ]), cargo, d));
  g.add(mesh(extrudeProfile(sc([[2.36, 3.25], [2.36, 3.46], [2.33, 3.56], [2.28, 3.46], [2.28, 3.25]]), W * 0.9, 0.02 * s, real), cargo, d));
  bandMats.forEach((m, i) => {
    const y = (1.65 + i * 0.32) * s;
    g.add(mesh(mergeGeometries([
      partBox(0.012 * s, 0.14 * s, len, W / 2 + 0.006 * s, y, mid), partBox(0.012 * s, 0.14 * s, len, -W / 2 - 0.006 * s, y, mid),
      partBox(W, 0.14 * s, 0.012 * s, 0, y, z1 - t / 2 - 0.006 * s),
    ]), m, d));
  });
  // Chassis rails, bumper, mudflaps, the stack beside the cab.
  const trimParts: THREE.Mesh[] = [
    partBox(0.18 * s, 0.24 * s, 8.0 * s, 0.45 * s, 0.82 * s, 0.1 * s), partBox(0.18 * s, 0.24 * s, 8.0 * s, -0.45 * s, 0.82 * s, 0.1 * s),
    partBox(W * 1.02, 0.32 * s, 0.16 * s, 0, 0.62 * s, 4.32 * s),
    partBox(0.5 * s, 0.6 * s, 0.03 * s, W * 0.33, 0.45 * s, rearAxle - 0.7 * s), partBox(0.5 * s, 0.6 * s, 0.03 * s, -W * 0.33, 0.45 * s, rearAxle - 0.7 * s),
    partRod(0.07 * s, 2.3 * s, W / 2 - 0.12 * s, 2.25 * s, 2.45 * s),
  ];
  if (real) {
    for (const sx of [-1, 1]) trimParts.push(partBox(0.08 * s, 0.4 * s, 0.22 * s, sx * (W / 2 + 0.2 * s), 2.55 * s, 4.05 * s));
  }
  g.add(mesh(mergeGeometries(trimParts), trim, d));
  for (const sx of [-1, 1]) {
    g.add(lamp(0xfff3d0, 0.3 * s, 0.2 * s, sx * W * 0.34, 1.05 * s, 4.33 * s));
    g.add(lamp(0xd82b1e, 0.22 * s, 0.16 * s, sx * W * 0.4, 1.0 * s, z1 - 0.1 * s));
  }

  const tw = 0.3 * s;
  for (const sx of [-1, 1]) {
    const f = roadWheel(r, tw, sx, d, wm, 8);
    f.position.set(sx * (W / 2 - tw / 2 - 0.04 * s), r, frontAxle);
    g.add(f);
    const outer = roadWheel(r, tw, sx, d, wm, 8);
    outer.position.set(sx * (W / 2 - tw / 2 - 0.04 * s), r, rearAxle);
    const inner = roadWheel(r, tw, sx, d, wm, 8);
    inner.position.set(sx * (W / 2 - tw * 1.55 - 0.04 * s), r, rearAxle);
    g.add(outer, inner);
  }
  return g;
}

export interface TractorOptions extends BaseOpts { color?: number; length?: number }

/**
 * A tractor: 3.6 m long, 2.0 m wide, 2.6 m tall, REAR wheels of 0.75 m radius and front ones of 0.40 m.
 * The huge-rear, small-front mismatch IS the tractor — equal wheels make it a truck — with a deep
 * chevron tread, a narrow bonnet, the exhaust stack in front of the driver and the open seat above the
 * rear axle.
 */
export function createTractor(options: TractorOptions = {}): THREE.Group {
  const d = tier(options);
  const real = d === 'real';
  const s = (options.length ?? 3.6) / 3.6;
  const paint = vehiclePaint(options.color ?? 0xc62828, d);
  const dark = new THREE.MeshStandardMaterial({ color: 0x1d1f22, roughness: 0.6, metalness: 0.5 });
  const seatMat = new THREE.MeshStandardMaterial({ color: 0x2a2420, roughness: 0.8 });
  const chrome = new THREE.MeshStandardMaterial({ color: 0xd0d4d8, roughness: 0.3, metalness: 1 });
  const rimPaint = new THREE.MeshStandardMaterial({ color: 0xe0b100, roughness: 0.5, metalness: 0.3 });
  const tyreMat = shared('fabric', d, 0x141518, 2);
  const g = new THREE.Group();
  const sc = (pts: number[][]) => pts.map(([z, y]) => [z * s, y * s]);
  const rr = 0.75 * s, fr = 0.4 * s;
  const rearZ = -0.75 * s, frontZ = 1.25 * s;

  // Bonnet and engine — narrow, rising slightly toward the driver.
  g.add(mesh(extrudeProfile(sc([[1.8, 0.62], [1.82, 1.36], [1.72, 1.48], [0.1, 1.52], [-0.12, 1.56], [-0.16, 0.62]]), 0.76 * s, 0.05 * s, real), paint, d));
  // Transmission housing under the seat.
  g.add(mesh(extrudeProfile(sc([[-0.1, 0.62], [-0.1, 1.05], [-1.05, 1.05], [-1.12, 0.62]]), 0.9 * s, 0.04 * s, real), dark, d));
  // Mudguards over the big rear wheels: half shells in the body colour, with a flat top to sit a hand on.
  for (const sx of [-1, 1]) {
    const guard = mesh(new THREE.CylinderGeometry(rr + 0.08 * s, rr + 0.08 * s, 0.5 * s, real ? 20 : 10, 1, true, -0.25, Math.PI * 0.7), paint, d);
    guard.rotation.z = Math.PI / 2;
    guard.position.set(sx * 0.82 * s, rr, rearZ);
    g.add(guard);
  }
  g.add(mesh(mergeGeometries([
    partBox(0.5 * s, 0.1 * s, 0.45 * s, 0, 1.36 * s, -0.86 * s),                     // the seat
    partBox(0.5 * s, 0.38 * s, 0.08 * s, 0, 1.58 * s, -1.1 * s, -0.15),
  ]), seatMat, d));
  const dash: THREE.Mesh[] = [
    partRod(0.05 * s, 0.9 * s, 0.22 * s, 1.95 * s, 0.9 * s),                          // the stack, in front of the driver
    partRod(0.025 * s, 0.5 * s, 0, 1.68 * s, -0.12 * s, -0.6),                        // steering column
    partBox(0.62 * s, 0.32 * s, 0.05 * s, 0, 1.0 * s, 1.83 * s),                      // grille
  ];
  g.add(mesh(mergeGeometries(dash), dark, d));
  const steer = mesh(new THREE.TorusGeometry(0.18 * s, 0.018 * s, 6, real ? 20 : 10), dark, d);
  steer.position.set(0, 1.86 * s, -0.27 * s);
  steer.rotation.x = -Math.PI / 2 + 0.6;
  g.add(steer);
  if (real) g.add(mesh(mergeGeometries([partRod(0.06 * s, 0.08 * s, 0.22 * s, 2.42 * s, 0.9 * s)]), chrome, d));
  for (const sx of [-1, 1]) g.add(lamp(0xfff3d0, 0.14 * s, 0.12 * s, sx * 0.24 * s, 1.0 * s, 1.85 * s));

  for (const sx of [-1, 1]) {
    // At the real tier the chevron lugs ARE the outer 4.5 cm of the tyre: the carcass is smaller by that
    // much and the lugs end exactly at the wheel's radius, so the tread meets the road instead of sinking in.
    const lugDepth = real ? 0.045 * s : 0;
    const rear = roadWheel(rr - lugDepth, 0.42 * s, sx, d, { tyre: tyreMat, rim: rimPaint, rimInner: rimPaint }, 6);
    if (real) {
      // The chevron tread: angled lugs round the tyre, two per step, rolling with the wheel.
      const lugs: THREE.Mesh[] = [];
      const n = 22;
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2;
        for (const half of [-1, 1]) {
          const lug = partBox(0.2 * s, lugDepth + 0.02 * s, 0.11 * s, half * 0.1 * s, Math.cos(a) * (rr - (lugDepth + 0.02 * s) / 2), Math.sin(a) * (rr - (lugDepth + 0.02 * s) / 2), a, half * 0.45);
          lugs.push(lug);
        }
      }
      rear.add(mesh(mergeGeometries(lugs), tyreMat, d));
    }
    rear.position.set(sx * 0.82 * s, rr, rearZ);
    g.add(rear);
    const front = roadWheel(fr, 0.2 * s, sx, d, { tyre: tyreMat, rim: rimPaint, rimInner: rimPaint }, 5);
    front.position.set(sx * 0.66 * s, fr, frontZ);
    g.add(front);
  }
  return g;
}

// ── WEAPONS (models) ─────────────────────────────────────────────────────────────────────────────
export type WeaponModelKind = 'pistol' | 'rifle' | 'smg' | 'shotgun' | 'sniper' | 'sword' | 'axe' | 'bow';
export interface WeaponModelOptions extends BaseOpts { kind?: WeaponModelKind }
export interface WeaponModel {
  root: THREE.Group;
  /** The barrel tip (or arrow rest, or blade tip). Read its world position to fire from it. */
  muzzle: THREE.Object3D;
  kind: WeaponModelKind;
  /**
   * Bow only: draw it, 0 (at rest) to 1 (full draw). The limbs bend back, the string pulls into a V and an
   * arrow sits on it while it is drawn. Drive it from the trigger: `model.setDraw?.(held ? 1 : 0)` — or ease
   * toward it for a slow, tense draw.
   */
  setDraw?: (amount: number) => void;
}

/**
 * A hand-held weapon at real size, built from its own side profile like the vehicles — a gun is a stock,
 * a receiver, a magazine and a grip, not a box with a cylinder on it. The GRIP is at the origin and the
 * barrel points along +Z, so humanoid.hold(weapon.root) puts it in the hand pointing where the arm points.
 * Pair it with the Weapon / MeleeWeapon systems (generate_game_systems, weapon.ts) for how it fires.
 */
export function createWeapon(options: WeaponModelOptions = {}): WeaponModel {
  const d = tier(options);
  const real = d === 'real';
  const kind = options.kind ?? 'rifle';
  const root = new THREE.Group();
  const gunmetal = new THREE.MeshStandardMaterial({ color: 0x23262b, roughness: 0.45, metalness: 0.8 });
  const polymer = new THREE.MeshStandardMaterial({ color: 0x15171a, roughness: 0.7, metalness: 0.1 });
  const wood = shared('wood', d, 0x7a4a26, 1);
  const steel = new THREE.MeshStandardMaterial({ color: 0xd5d9de, roughness: 0.2, metalness: 1 });
  const muzzle = new THREE.Object3D();
  muzzle.name = 'muzzle';
  const barrel = (r: number, z0: number, z1: number, y: number, mat: THREE.Material) => {
    const b = mesh(new THREE.CylinderGeometry(r, r, z1 - z0, real ? 12 : 6), mat, d);
    b.rotation.x = Math.PI / 2;
    b.position.set(0, y, (z0 + z1) / 2);
    root.add(b);
  };
  const body = (pts: number[][], width: number, mat: THREE.Material) => root.add(mesh(extrudeProfile(pts, width, Math.min(0.006, width / 4), real), mat, d));

  if (kind === 'pistol') {
    body([[-0.05, 0.0], [-0.06, 0.06], [0.15, 0.06], [0.15, 0.01], [0.02, 0.0], [0.0, -0.1], [-0.045, -0.11], [-0.03, 0.0]], 0.03, gunmetal);
    barrel(0.008, 0.15, 0.165, 0.04, polymer);
    muzzle.position.set(0, 0.04, 0.165);
  } else if (kind === 'rifle' || kind === 'smg') {
    const k = kind === 'smg' ? 0.62 : 1;
    // Stock, receiver, handguard, the magazine curving forward and the pistol grip — one outline.
    body([[-0.42 * k, -0.12], [-0.42 * k, 0.03], [-0.15, 0.06], [0.36 * k, 0.06], [0.36 * k, -0.02], [0.1, -0.02],
      [0.1, -0.2], [0.04, -0.2], [0.03, -0.03], [-0.02, -0.03], [-0.05, -0.12], [-0.1, -0.12], [-0.08, -0.03], [-0.16, -0.03], [-0.3 * k, -0.12]], 0.045, polymer);
    barrel(0.011, 0.36 * k, 0.58 * k, 0.035, gunmetal);
    if (real) root.add(mesh(mergeGeometries([partBox(0.02, 0.03, 0.12, 0, 0.08, 0.0), partBox(0.012, 0.035, 0.02, 0, 0.078, 0.33 * k)]), gunmetal, d));
    muzzle.position.set(0, 0.035, 0.58 * k);
  } else if (kind === 'shotgun') {
    body([[-0.45, -0.13], [-0.45, 0.02], [-0.18, 0.05], [0.05, 0.05], [0.05, -0.03], [-0.06, -0.03], [-0.1, -0.12], [-0.15, -0.12], [-0.13, -0.03], [-0.25, -0.05]], 0.045, wood);
    barrel(0.016, 0.05, 0.62, 0.035, gunmetal);
    // The pump: a wooden fore-end round the magazine tube.
    const pump = mesh(new THREE.CylinderGeometry(0.024, 0.024, 0.2, real ? 12 : 6), wood, d);
    pump.rotation.x = Math.PI / 2;
    pump.position.set(0, 0.0, 0.32);
    root.add(pump);
    muzzle.position.set(0, 0.035, 0.62);
  } else if (kind === 'sniper') {
    body([[-0.5, -0.13], [-0.5, 0.03], [-0.2, 0.05], [0.3, 0.05], [0.3, -0.03], [-0.04, -0.03], [-0.08, -0.13], [-0.14, -0.13], [-0.12, -0.03], [-0.3, -0.06]], 0.05, new THREE.MeshStandardMaterial({ color: 0x4b5340, roughness: 0.7 }));
    barrel(0.012, 0.3, 0.85, 0.035, gunmetal);
    barrel(0.024, -0.12, 0.16, 0.11, polymer);   // the scope
    muzzle.position.set(0, 0.035, 0.85);
  } else if (kind === 'sword') {
    // A blade that tapers to a point, a crossguard, a wrapped grip and a pommel.
    // The blade is LOFTED, not extruded: a diamond section at every station, so it thins toward the point
    // AND toward both edges and its faces catch the light as a ground bevel. An extruded slab of one
    // thickness reads as a ruler.
    const stations: number[][] = [];
    for (let k = 0; k <= 8; k++) { const t = k / 8; stations.push([0.1 + 0.72 * t, 0.024 - 0.006 * t, 0.0045 - 0.0017 * t]); }
    stations.push([0.92, 0.0004, 0.0004]);
    const ring = (st: number[]) => [[0, st[1], st[0]], [st[2], 0, st[0]], [0, -st[1], st[0]], [-st[2], 0, st[0]]];
    const tri: number[] = [];
    for (let k = 0; k + 1 < stations.length; k++) {
      const a = ring(stations[k]), c = ring(stations[k + 1]);
      for (let f = 0; f < 4; f++) {
        const g = (f + 1) % 4;
        tri.push(...a[f], ...a[g], ...c[g], ...a[f], ...c[g], ...c[f]);
      }
    }
    const base = ring(stations[0]);
    tri.push(...base[0], ...base[2], ...base[1], ...base[0], ...base[3], ...base[2]);
    const blade = new THREE.BufferGeometry();
    blade.setAttribute('position', new THREE.Float32BufferAttribute(tri, 3));
    blade.computeVertexNormals();      // non-indexed: every facet keeps its own normal — a crisp bevel
    const bladeMesh = mesh(blade, steel, d);
    bladeMesh.name = 'blade';
    root.add(bladeMesh);
    root.add(mesh(mergeGeometries([partBox(0.03, 0.2, 0.03, 0, 0, 0.09)]), gunmetal, d));
    barrel(0.016, -0.1, 0.08, 0, new THREE.MeshStandardMaterial({ color: 0x3b2416, roughness: 0.8 }));
    const pommel = mesh(new THREE.SphereGeometry(0.025, 10, 8), gunmetal, d);
    pommel.position.z = -0.11;
    root.add(pommel);
    muzzle.position.set(0, 0, 0.92);
  } else if (kind === 'axe') {
    barrel(0.018, -0.15, 0.6, 0, wood);
    // The head: a flared bit on one side, a poll on the other.
    body([[0.5, 0.0], [0.62, 0.0], [0.66, 0.18], [0.46, 0.2], [0.52, 0.05]], 0.03, steel);
    muzzle.position.set(0, 0.1, 0.66);   // the leading edge of the bit
  } else {
    // Bow, held upright: two limbs sweeping forward from a wrapped grip at the origin, 1.5 m tip to tip,
    // the string 0.2 m behind the grip at rest (the brace height). Each limb pivots at the grip, so a draw
    // bends both back; the string is two segments meeting at the nock, and the arrow rides on it.
    const R = 1.5, half = 0.75, brace = 0.2, DRAW = 0.55, lean = 0.13;
    const sweep = Math.asin(half / R);
    const limbs: THREE.Group[] = [];
    const tips: THREE.Vector3[] = [];
    for (const side of [1, -1]) {
      const pts: THREE.Vector3[] = [];
      for (let i = 0; i <= 8; i++) {
        const a = 0.04 + ((sweep - 0.04) * i) / 8;
        pts.push(new THREE.Vector3(0, side * (R * Math.sin(a) - 0.06), -(R - R * Math.cos(a))));
      }
      const limb = new THREE.Group();
      limb.position.y = side * 0.06;
      limb.add(mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), real ? 24 : 8, 0.014, real ? 8 : 5), wood, d));
      root.add(limb);
      limbs.push(limb);
      tips.push(pts[pts.length - 1].clone());
    }
    const grip = mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.14, real ? 10 : 6), new THREE.MeshStandardMaterial({ color: 0x3b2416, roughness: 0.85 }), d);
    root.add(grip);
    const cord = new THREE.MeshStandardMaterial({ color: 0xe8e2d0, roughness: 0.6 });
    const strings = [0, 1].map(() => { const s = mesh(new THREE.CylinderGeometry(0.0025, 0.0025, 1, 4), cord, d); root.add(s); return s; });
    // The arrow: shaft, head and fletching, its nock end at the group's origin, pointing +Z.
    const arrow = new THREE.Group();
    const shaft = mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.72, real ? 6 : 4), wood, d);
    shaft.rotation.x = Math.PI / 2; shaft.position.z = 0.36;
    const head = mesh(new THREE.ConeGeometry(0.01, 0.04, real ? 6 : 4), steel, d);
    head.rotation.x = Math.PI / 2; head.position.z = 0.74;
    arrow.add(shaft, head);
    for (let k = 0; k < 3; k++) {
      const vane = mesh(new THREE.BoxGeometry(0.001, 0.014, 0.08), new THREE.MeshStandardMaterial({ color: 0xc0392b, roughness: 0.7 }), d);
      const a = (k * Math.PI * 2) / 3;
      vane.position.set(Math.sin(a) * 0.009, Math.cos(a) * 0.009, 0.07);
      vane.rotation.z = -a;
      arrow.add(vane);
    }
    root.add(arrow);
    const up = new THREE.Vector3(0, 1, 0), tip = new THREE.Vector3(), nock = new THREE.Vector3(), seg = new THREE.Vector3();
    const setDraw = (amount: number) => {
      const t = Math.max(0, Math.min(1, amount));
      const nockZ = -brace - DRAW * t;
      nock.set(0, 0, nockZ);
      limbs.forEach((limb, k) => {
        const side = k === 0 ? 1 : -1;
        limb.rotation.x = -side * lean * t;
        tip.copy(tips[k]).applyEuler(limb.rotation).add(limb.position);
        seg.subVectors(nock, tip);
        const s = strings[k];
        s.position.copy(tip).addScaledVector(seg, 0.5);
        s.scale.y = seg.length();
        s.quaternion.setFromUnitVectors(up, seg.normalize());
      });
      arrow.visible = t > 0.02;
      arrow.position.z = nockZ;
    };
    setDraw(0);
    muzzle.position.set(0, 0.02, 0.03);   // the arrow rest, just above the grip
    root.add(muzzle);
    return { root, muzzle, kind, setDraw };
  }
  root.add(muzzle);
  return { root, muzzle, kind };
}

// ── TRAFFIC ──────────────────────────────────────────────────────────────────────────────────────
export type TrafficKind = 'car' | 'auto' | 'bus' | 'truck' | 'tractor';

export interface TrafficOptions extends BaseOpts {
  /** The road it runs on — createRoad's own length and width. Lanes are its two halves. */
  road?: { length?: number; width?: number };
  count?: number;
  kinds?: TrafficKind[];
  /** Multiplies every vehicle's cruising speed. */
  speed?: number;
}

export interface TrafficVehicle {
  object: THREE.Group;
  kind: TrafficKind;
  /** +1 drives toward +Z in the +X lane; −1 drives toward −Z in the −X lane (India keeps LEFT). */
  dir: 1 | -1;
  speed: number;
  cruise: number;
  length: number;
}

export interface Traffic {
  root: THREE.Group;
  vehicles: TrafficVehicle[];
  /**
   * Advance the traffic. `avoid` is what it must never drive into — the player, the player's car: a
   * vehicle with one of them ahead in its lane slows and stops behind it.
   */
  update: (dt: number, avoid?: THREE.Object3D[]) => void;
}

/** City cruising speeds, m/s (a car ≈ 47 km/h, a tractor ≈ 22). */
export const TRAFFIC_CRUISE: Readonly<Record<TrafficKind, number>> = { car: 13, auto: 9, bus: 10, truck: 9, tractor: 6 };
/** Gap kept to the vehicle ahead: a standstill margin plus a time headway. */
export const TRAFFIC_GAP = { standstill: 2.5, headway: 1.2 } as const;

/**
 * LIVE TRAFFIC on a road — what makes a driving or city game feel inhabited rather than staged. Vehicles
 * keep LEFT (India), cruise at their own kind's speed, keep a safe time-gap to whatever is ahead in their
 * lane (so a car behind a tractor slows to the tractor's pace instead of driving through it), stop for
 * the player, and loop round at the road's end without spawning into one another. Same seed, same traffic.
 */
export function createTraffic(options: TrafficOptions = {}): Traffic {
  const d = tier(options);
  const L = options.road?.length ?? 300;
  const W = options.road?.width ?? 8;
  const count = Math.max(1, Math.round(options.count ?? 8));
  const kinds = options.kinds && options.kinds.length ? options.kinds : (['car', 'auto', 'bus', 'truck', 'car', 'auto', 'tractor', 'car'] as TrafficKind[]);
  const pace = options.speed ?? 1;
  const rand = rng(options.seed ?? 7);
  const root = new THREE.Group();
  const paints = [0xb42b2b, 0x1d4ed8, 0xf3f4f6, 0x111827, 0x9ca3af, 0x0f766e];
  const build = (k: TrafficKind): THREE.Group => {
    if (k === 'auto') return createAutoRickshaw({ detail: d, livery: rand() < 0.5 ? 'delhi' : 'mumbai' });
    if (k === 'bus') return createBus({ detail: d });
    if (k === 'truck') return createTruck({ detail: d });
    if (k === 'tractor') return createTractor({ detail: d });
    return createCar({ detail: d, color: paints[Math.floor(rand() * paints.length)] });
  };
  const lengthOf = (o: THREE.Object3D) => { o.updateMatrixWorld(true); return new THREE.Box3().setFromObject(o).getSize(new THREE.Vector3()).z; };

  const vehicles: TrafficVehicle[] = [];
  const perLane: Record<string, number> = { '1': 0, '-1': 0 };
  for (let i = 0; i < count; i++) {
    const kind = kinds[i % kinds.length];
    const dir: 1 | -1 = i % 2 === 0 ? 1 : -1;
    const object = build(kind);
    const length = lengthOf(object);
    const cruise = TRAFFIC_CRUISE[kind] * pace * (0.88 + rand() * 0.24);
    vehicles.push({ object, kind, dir, speed: cruise, cruise, length });
    perLane[String(dir)] += 1;
  }
  // Spread each lane's vehicles evenly along the road, so the first frame has no pile-up.
  const placed: Record<string, number> = { '1': 0, '-1': 0 };
  for (const v of vehicles) {
    const n = perLane[String(v.dir)];
    const k = placed[String(v.dir)]++;
    const along = -L / 2 + ((k + 0.5) / n) * L;
    v.object.position.set(v.dir * (W / 4), ROAD_SURFACE_Y, along * v.dir);
    v.object.rotation.y = v.dir === 1 ? 0 : Math.PI;
    root.add(v.object);
  }

  /** Distance along v's direction of travel from v's nose to the nearest obstacle's tail in its lane. */
  const gapAhead = (v: TrafficVehicle, avoid: THREE.Object3D[]): { gap: number; speed: number } => {
    let best = Infinity, bestSpeed = 0;
    const s = v.object.position.z * v.dir;
    for (const o of vehicles) {
      if (o === v || o.dir !== v.dir) continue;
      let ahead = o.object.position.z * o.dir - s;
      if (ahead <= 0) ahead += L;                       // the lane loops: the leader may be round the end
      const gap = ahead - (v.length + o.length) / 2;
      if (gap < best) { best = gap; bestSpeed = o.speed; }
    }
    for (const a of avoid) {
      const p = a.position;
      if (Math.abs(p.x - v.object.position.x) > W / 4 + 0.6) continue;   // not in this lane
      const ahead = p.z * v.dir - s;
      if (ahead <= 0 || ahead > 60) continue;
      const gap = ahead - v.length / 2 - 0.8;
      if (gap < best) { best = gap; bestSpeed = 0; }
    }
    return { gap: best, speed: bestSpeed };
  };

  const update = (dt: number, avoid: THREE.Object3D[] = []) => {
    const step = Math.min(0.1, Math.max(0, dt));
    for (const v of vehicles) {
      const { gap, speed: leaderSpeed } = gapAhead(v, avoid);
      const wanted = TRAFFIC_GAP.standstill + v.speed * TRAFFIC_GAP.headway;
      let target = v.cruise;
      if (gap < wanted) {
        // Match the leader's pace, scaled down the tighter the gap gets; stop at the standstill margin.
        const room = Math.max(0, (gap - TRAFFIC_GAP.standstill) / Math.max(0.1, wanted - TRAFFIC_GAP.standstill));
        target = Math.min(v.cruise, leaderSpeed + (v.cruise - leaderSpeed) * room * 0.5) * Math.min(1, room + 0.2);
        if (gap <= TRAFFIC_GAP.standstill * 0.5) target = 0;
      }
      const accel = target > v.speed ? 2.5 : 7;          // gentle away, firm braking
      v.speed += Math.sign(target - v.speed) * Math.min(Math.abs(target - v.speed), accel * step);
      // Never move further than the room there is: two vehicles can never overlap, whatever the step.
      const move = Math.min(v.speed * step, Math.max(0, gap - 0.3));
      if (move < v.speed * step) v.speed = move / Math.max(1e-6, step);
      v.object.position.z += move * v.dir;
      // Round the end of the road, back on at the start of its own lane.
      const along = v.object.position.z * v.dir;
      if (along > L / 2) v.object.position.z = (along - L) * v.dir;
      rollWheels(v.object, v.speed, step);
    }
  };

  return { root, vehicles, update };
}

// ── DRIVING ──────────────────────────────────────────────────────────────────────────────────────
/**
 * THE ONE FORWARD. Every model in this file — car, motorcycle, bicycle, animal, house — faces its local
 * +Z (headlights, handlebars, head and front door are all on +Z). Drive, aim and place by THIS, and put
 * the camera behind it with CameraRig.follow(). Want a car to drive "into the screen" (−Z)? Turn it:
 * car.rotation.y = Math.PI — never mirror a model or flip a control to fake it.
 */
export const MODEL_FORWARD = new THREE.Vector3(0, 0, 1);

export interface VehicleTuning {
  /** Top speed, m/s (≈ 25 = 90 km/h). */
  maxSpeed?: number;
  reverseSpeed?: number;
  /** Acceleration, m/s². */
  accel?: number;
  brake?: number;
  /** Fraction of speed lost per second when coasting. */
  drag?: number;
  /** Turn rate at full lock, radians per second. */
  steerRate?: number;
  /** Speed at start. NOT zero: a racing/driving game whose car sits still reads as broken. */
  startSpeed?: number;
}
export interface VehicleState { speed: number; heading: number }

/** The vehicle's state, starting from where the model already points (its rotation.y). */
export function createVehicleState(vehicle: THREE.Object3D, tuning: VehicleTuning = {}): VehicleState {
  return { speed: tuning.startSpeed ?? 5, heading: vehicle.rotation.y };
}

/**
 * Drive a vehicle from the RAW input axis — `input.axis()` exactly as the runtime gives it — so the
 * signs are decided here, once, and cannot be got wrong in a game:
 *   • up / W (axis.y = −1) → accelerate TOWARD THE FRONT (+Z of the model); down / S brakes, then reverses;
 *   • left / A (axis.x = −1) → turn to the DRIVER'S left; right / D → the driver's right — which, with
 *     the camera behind (CameraRig.follow), is also the left and right of the SCREEN.
 * Steering follows the direction of travel, so reversing steers like a real car, and it fades in with
 * speed, so a parked car does not spin on the spot. Wheels roll if the model has them (createCar).
 *
 * 🔴 WHY THIS EXISTS (admin 2026-10-05, "button ulte kaam karte hai"): the runtime's up key is −1, and a
 * game that used axis.y as throttle drove BACKWARDS on W; with the camera in front of the car on top of
 * that, every control felt mirrored. Call this; never hand-write a car's movement.
 */
export function driveVehicle(
  vehicle: THREE.Object3D,
  state: VehicleState,
  axis: { x: number; y: number },
  dt: number,
  tuning: VehicleTuning = {},
): VehicleState {
  const maxSpeed = tuning.maxSpeed ?? 25;
  const reverseSpeed = tuning.reverseSpeed ?? 6;
  const accel = tuning.accel ?? 9;
  const brake = tuning.brake ?? 18;
  const drag = tuning.drag ?? 0.35;
  const steerRate = tuning.steerRate ?? 1.6;

  const throttle = -axis.y; // up is −1 in the runtime; here up means "go forward"
  let speed = state.speed;
  if (throttle > 0.05) {
    speed += accel * throttle * dt;
  } else if (throttle < -0.05) {
    if (speed > 0.5) speed -= brake * -throttle * dt;            // braking first…
    else speed -= accel * 0.6 * -throttle * dt;                   // …then reversing
  } else {
    speed -= speed * drag * dt;                                   // coasting
  }
  speed = Math.max(-reverseSpeed, Math.min(maxSpeed, speed));

  // Positive rotation.y turns +Z toward +X, the DRIVER'S LEFT — so a right turn lowers the heading.
  const grip = Math.min(1, Math.abs(speed) / 4);
  const heading = state.heading - axis.x * steerRate * grip * Math.sign(speed) * dt;

  vehicle.rotation.y = heading;
  vehicle.position.x += Math.sin(heading) * speed * dt;
  vehicle.position.z += Math.cos(heading) * speed * dt;
  if (vehicle.children.some((c) => c.name === 'wheel')) rollWheels(vehicle as THREE.Group, speed, dt);
  return { speed, heading };
}

// ── TREE ─────────────────────────────────────────────────────────────────────────────────────────
export interface TreeOptions extends BaseOpts { height?: number; leafColor?: number }

/**
 * A tree with a TAPERED, root-flared trunk and real recursive branches, with leaves in clusters at the
 * BRANCH ENDS.
 *
 * The classic AI tree is a cylinder with a green sphere on top, and the reason it looks wrong is not
 * detail — it is that real trunks taper and flare, and real leaves grow where the branches end.
 */
export function createTree(options: TreeOptions = {}): THREE.Group {
  const d = tier(options);
  const H = options.height ?? 6;
  const r = rng(options.seed ?? 7);
  const group = new THREE.Group();
  const barkMat = shared('bark', d, 0x6b5236, 2);
  const leafMat = d === 'real'
    ? new THREE.MeshStandardMaterial({ color: options.leafColor ?? 0x4c7a2e, roughness: 0.9, metalness: 0, side: THREE.DoubleSide })
    : new THREE.MeshStandardMaterial({ color: options.leafColor ?? 0x4c7a2e, roughness: 0.9, flatShading: true });

  const trunkH = H * 0.45;
  // Taper: the top radius is a third of the base. Root flare is the wider disc at the ground.
  const trunk = mesh(new THREE.CylinderGeometry(H * 0.026, H * 0.075, trunkH, d === 'real' ? 12 : 6), barkMat, d);
  trunk.position.y = trunkH / 2;
  group.add(trunk);
  if (d === 'real') {
    const flare = mesh(new THREE.CylinderGeometry(H * 0.075, H * 0.11, H * 0.06, 12), barkMat, d);
    flare.position.y = H * 0.03;
    group.add(flare);
  }

  const branches = d === 'real' ? 6 : 3;
  const leafGeo = d === 'real'
    ? new THREE.IcosahedronGeometry(H * 0.16, 1)
    : new THREE.IcosahedronGeometry(H * 0.2, 0);

  for (let i = 0; i < branches; i++) {
    const angle = (i / branches) * Math.PI * 2 + r() * 0.6;
    // Branches leave the trunk at 30-50 degrees, thinner than it, and higher ones are shorter.
    const t = 0.55 + (i / branches) * 0.4;
    const len = H * (0.32 - t * 0.12) * (0.8 + r() * 0.4);
    const lift = Math.PI / 2 - (0.55 + r() * 0.35);
    const b = mesh(new THREE.CylinderGeometry(H * 0.012, H * 0.024, len, d === 'real' ? 8 : 5), barkMat, d);
    const pivot = new THREE.Group();
    pivot.position.y = trunkH * t;
    pivot.rotation.y = angle;
    pivot.rotation.z = lift - Math.PI / 2;
    b.position.y = len / 2;
    pivot.add(b);
    // Leaves at the END of the branch, which is where they actually grow.
    const cluster = mesh(leafGeo.clone(), leafMat, d);
    cluster.scale.setScalar(0.7 + r() * 0.5);
    cluster.position.y = len * (d === 'real' ? 0.95 : 0.85);
    pivot.add(cluster);
    group.add(pivot);
  }
  // A crown so the canopy closes over the middle instead of leaving a bald trunk top.
  const crown = mesh(leafGeo.clone(), leafMat, d);
  crown.scale.setScalar(d === 'real' ? 1.25 : 1.5);
  crown.position.y = trunkH + H * 0.12;
  group.add(crown);
  return group;
}

// ── MOUNTAIN ─────────────────────────────────────────────────────────────────────────────────────
export interface MountainOptions extends BaseOpts { size?: number; height?: number; snow?: boolean }

/**
 * A mountain built by displacing a plane along RIDGES, with a snow line by altitude.
 *
 * A cone is not a mountain. What the eye reads is ridge lines running down from the peak and the
 * valleys between them, plus snow that starts at a height rather than being painted on the top.
 */
export function createMountain(options: MountainOptions = {}): THREE.Mesh {
  const d = tier(options);
  const size = options.size ?? 120;
  const H = options.height ?? 45;
  const seg = d === 'real' ? 96 : 32;
  const r = rng(options.seed ?? 31);
  const offsets = Array.from({ length: 8 }, () => r() * Math.PI * 2);

  const geo = new THREE.PlaneGeometry(size, size, seg, seg);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position as THREE.BufferAttribute;
  const colors = new Float32Array(pos.count * 3);
  const rock = new THREE.Color(0x6d6a63);
  const snow = new THREE.Color(0xf2f5f8);
  const grass = new THREE.Color(0x4a5c35);

  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i);
    const dist = Math.sqrt(x * x + z * z) / (size / 2);
    // A dome that falls off to nothing at the edge — no cliff at the boundary of the tile.
    const base = Math.max(0, 1 - dist) ** 1.7;
    const theta = Math.atan2(z, x);
    // RIDGES: several angular waves, each sharpened with abs() so they crease instead of rolling.
    let ridge = 0;
    for (let k = 0; k < (d === 'real' ? 5 : 2); k++) {
      ridge += (1 - Math.abs(Math.sin(theta * (2 + k * 1.7) + offsets[k]))) / (k + 1.6);
    }
    const detail = d === 'real' ? (Math.sin(x * 0.35 + offsets[5]) * Math.cos(z * 0.31 + offsets[6])) * 0.06 : 0;
    const y = H * base * (0.55 + ridge * 0.5) + H * detail * base;
    pos.setY(i, y);

    const alt = y / H;
    const c = options.snow !== false && alt > 0.62 ? snow : alt < 0.12 ? grass : rock;
    // Blend across the snow line rather than a hard edge, which is what makes it look painted on.
    const mix = options.snow !== false && alt > 0.5 && alt <= 0.62 ? (alt - 0.5) / 0.12 : 0;
    const col = mix > 0 ? rock.clone().lerp(snow, mix) : c;
    colors[i * 3] = col.r; colors[i * 3 + 1] = col.g; colors[i * 3 + 2] = col.b;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geo.computeVertexNormals();

  const mat = d === 'real'
    ? surfaceMaterial('stone', { repeat: 14 })
    : new THREE.MeshStandardMaterial({ roughness: 0.95, metalness: 0, flatShading: true });
  mat.vertexColors = true;
  const m = mesh(geo, mat, d);
  m.castShadow = false; // A whole mountain casting into the shadow map eats the resolution.
  return m;
}

// ── RIVER ────────────────────────────────────────────────────────────────────────────────────────
export interface RiverOptions extends BaseOpts { length?: number; width?: number }
export interface River { mesh: THREE.Mesh; update: (t: number) => void }

/**
 * A river that MOVES. Still water is the fastest way to make a scene look like a screenshot, so the
 * surface scrolls two normal-ish waves against each other and the material is transmissive.
 */
/** Mean water level above the ground plane. Waves never dip below ground (amplitude is 0.1 m). */
export const RIVER_SURFACE_Y = 0.14;

export function createRiver(options: RiverOptions = {}): River {
  const d = tier(options);
  const L = options.length ?? 200;
  const W = options.width ?? 14;
  const segL = d === 'real' ? 200 : 60;
  const geo = new THREE.PlaneGeometry(W, L, d === 'real' ? 12 : 4, segL);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position as THREE.BufferAttribute;
  const base = new Float32Array(pos.count * 2);
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i);
    base[i * 2] = x; base[i * 2 + 1] = z;
    // The course MEANDERS. A straight river is a canal, and the eye knows the difference.
    pos.setX(i, x + Math.sin(z * 0.03) * W * 0.9 + Math.sin(z * 0.011) * W * 1.6);
  }
  geo.computeVertexNormals();

  const mat = new THREE.MeshPhysicalMaterial({
    color: d === 'real' ? 0x2d5f74 : 0x2f6f8a,
    roughness: d === 'real' ? 0.08 : 0.3,
    metalness: 0,
    transmission: d === 'real' ? 0.65 : 0,
    thickness: 2.2,
    transparent: true,
    opacity: d === 'real' ? 0.82 : 0.9,
  });
  const m = new THREE.Mesh(geo, mat);
  m.receiveShadow = true;

  const update = (t: number) => {
    const p = m.geometry.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < p.count; i++) {
      const x = base[i * 2], z = base[i * 2 + 1];
      // Two waves at different speeds and angles — one wave reads as a flag, two read as water.
      // 🔴 Around RIVER_SURFACE_Y, never around 0. The waves used to swing ±10 cm through the ground's
      // own plane, so wherever a trough dipped under y = 0 the grass covered the water and the river
      // rendered as scattered blue scraps (seen in a real render, 2026-10-05 — the road's bug again).
      p.setY(i, RIVER_SURFACE_Y + Math.sin(z * 0.35 + t * 1.7) * 0.06 + Math.sin(x * 0.5 - t * 1.1) * 0.04);
    }
    p.needsUpdate = true;
    m.geometry.computeVertexNormals();
  };
  update(0);
  return { mesh: m, update };
}

// ── DESERT ───────────────────────────────────────────────────────────────────────────────────────
export interface DesertOptions extends BaseOpts { size?: number }

/**
 * Dunes with a real wind shape: a long gentle windward slope and a SHORT STEEP slip face — sand
 * collapses at about 34 degrees, and that asymmetry is what separates a desert from bumpy ground.
 */
export function createDesert(options: DesertOptions = {}): THREE.Mesh {
  const d = tier(options);
  const size = options.size ?? 300;
  const seg = d === 'real' ? 128 : 40;
  const geo = new THREE.PlaneGeometry(size, size, seg, seg);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i);
    const wave = Math.sin(x * 0.045) * 0.5 + 0.5;
    // Skew the wave so its rise is long and its fall is short: the slip face.
    const skew = Math.pow(wave, 0.55);
    let y = skew * 5.5 + Math.sin(z * 0.02 + x * 0.01) * 1.8;
    if (d === 'real') y += Math.sin(x * 0.7 + z * 0.25) * 0.08; // wind ripples
    pos.setY(i, y);
  }
  geo.computeVertexNormals();
  const mat = d === 'real'
    ? surfaceMaterial('sand', { repeat: 30 })
    : new THREE.MeshStandardMaterial({ color: 0xd9b877, roughness: 0.95, metalness: 0 });
  const m = mesh(geo, mat, d);
  m.castShadow = false;
  return m;
}

// ── ROAD ─────────────────────────────────────────────────────────────────────────────────────────
export interface RoadOptions extends BaseOpts { length?: number; width?: number; lanes?: number }

/**
 * How high the road's surface sits above the ground plane (y = 0). Place a vehicle's wheels on it.
 *
 * 🔴 IT USED TO BE 0, and that was the worst-looking bug in the whole layer: the asphalt sat in exactly
 * the same plane as the ground, so the depth buffer could not decide which was in front and the road
 * flickered into black zebra stripes over the grass the moment the camera moved (seen in a real render,
 * 2026-10-05). Three centimetres is invisible to a player and is many depth steps at any distance a game
 * draws. Markings sit above the asphalt the same way, never in its plane.
 */
export const ROAD_SURFACE_Y = 0.03;

/**
 * Asphalt with the markings that make it a road rather than a grey strip: a dashed centre line, solid
 * edge lines and kerbs on BOTH sides. `real` also adds the darker worn tracks where wheels actually run.
 */
export function createRoad(options: RoadOptions = {}): THREE.Group {
  const d = tier(options);
  const L = options.length ?? 300;
  const W = options.width ?? 8;
  const lanes = options.lanes ?? 2;
  const group = new THREE.Group();

  const surface = mesh(new THREE.PlaneGeometry(W, L, 1, d === 'real' ? 60 : 1), shared('asphalt', d, 0x3a3c40, d === 'real' ? 40 : 1), d);
  surface.rotation.x = -Math.PI / 2;
  surface.position.y = ROAD_SURFACE_Y;
  surface.castShadow = false;
  group.add(surface);

  // polygonOffset pulls the paint toward the camera in DEPTH as well as lifting it, so a mark never
  // fights the asphalt under it even at a grazing angle far down the road.
  const paint = new THREE.MeshStandardMaterial({ color: 0xe8e4d8, roughness: 0.75, metalness: 0, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
  // Dashed centre line — 3 m mark, 6 m gap is close to the real Indian standard.
  const dashes = Math.floor(L / 9);
  for (let i = 0; i < dashes; i++) {
    const dash = new THREE.Mesh(new THREE.PlaneGeometry(0.14, 3), paint);
    dash.rotation.x = -Math.PI / 2;
    dash.position.set(0, ROAD_SURFACE_Y + 0.008, -L / 2 + i * 9 + 4.5);
    group.add(dash);
  }
  // BOTH sides. This loop used to end in `break` after the first pass, so a road had one edge line and
  // one kerb — and that kerb, at (side * W) / 2 + 0.15, sat INSIDE the asphalt on the left.
  for (const side of [-1, 1]) {
    const edge = new THREE.Mesh(new THREE.PlaneGeometry(0.12, L), paint);
    edge.rotation.x = -Math.PI / 2;
    edge.position.set(side * (W / 2 - 0.35), ROAD_SURFACE_Y + 0.008, 0);
    group.add(edge);
    if (d === 'real') {
      const kerb = mesh(new THREE.BoxGeometry(0.3, 0.16, L), shared('stone', d, 0xb9b3a6, 20), d);
      kerb.position.set(side * (W / 2 + 0.15), 0.08, 0);
      group.add(kerb);
    }
  }
  if (d === 'real') {
    // Worn wheel tracks — two slightly darker, slightly smoother bands per lane, built once (not once
    // per side) and sharing ONE material instead of a new one per band.
    const wearMat = new THREE.MeshStandardMaterial({ color: 0x303237, roughness: 0.72, metalness: 0, transparent: true, opacity: 0.3, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
    for (let lane = 0; lane < lanes; lane++) {
      const laneCentre = -W / 2 + (W / lanes) * (lane + 0.5);
      for (const off of [-0.75, 0.75]) {
        const wear = new THREE.Mesh(new THREE.PlaneGeometry(0.55, L), wearMat);
        wear.rotation.x = -Math.PI / 2;
        wear.position.set(laneCentre + off, ROAD_SURFACE_Y + 0.004, 0);
        group.add(wear);
      }
    }
  }
  return group;
}

// ── HOUSE ────────────────────────────────────────────────────────────────────────────────────────
export interface HouseOptions extends BaseOpts {
  width?: number;
  depth?: number;
  /** 1 or 2. Each storey is 3 m. */
  storeys?: number;
  /** Wall colour. Defaults to one of the washes Indian houses are actually painted in. */
  wallColor?: number;
  /** 'flat' — RCC roof with a parapet and a water tank (towns, most villages). 'tiled' — sloped clay tiles. */
  roof?: 'flat' | 'tiled';
}

/** The colours houses in an Indian village or town are really washed in — not white boxes. */
export const HOUSE_WASHES: readonly number[] = [0xe9c46a, 0xf4a6a6, 0x9ec9e6, 0xf1e3c8, 0xc7e0b4, 0xe8b07a, 0xd7c3e6];

/**
 * A HOUSE, not a box with a hat. What makes a building read as a home is the stuff on its face: a door
 * you could walk through, windows with frames and a sun-shade over them, a darker plinth where the wall
 * meets the ground, and a roof line — here the flat RCC roof with a parapet and a black water tank that
 * is on nearly every house in India, or sloped clay tiles. Front face is +Z; place it facing the road.
 *
 * Walls are textured plaster in `real` (the same plaster everywhere, tinted, so a street of ten houses
 * builds the texture ONCE). Returns a Group whose origin is the centre of the footprint at ground level.
 */
export function createHouse(options: HouseOptions = {}): THREE.Group {
  const d = tier(options);
  const r = rng(options.seed ?? 11);
  const W = options.width ?? 6 + r() * 3;
  const D = options.depth ?? 5 + r() * 2;
  const storeys = Math.max(1, Math.min(2, Math.round(options.storeys ?? 1)));
  const H = storeys * 3;
  const wash = options.wallColor ?? HOUSE_WASHES[Math.floor(r() * HOUSE_WASHES.length)];
  const roofKind = options.roof ?? (r() < 0.7 ? 'flat' : 'tiled');
  const group = new THREE.Group();

  const wall = shared('plaster', d, wash, 2);
  // Tints are chosen to read right in BOTH tiers: in `lite` the tint IS the colour, in `real` it is
  // MULTIPLIED by the texture's own colour — a dark tint on a dark texture goes black (the first render
  // of this house had a black plinth, black sun-shades and a black door).
  const plinthMat = shared('stone', d, 0xb8b0a4, 3);
  const concreteMat = shared('plaster', d, 0xd6d1c7, 2);
  const woodMat = shared('wood', d, 0xc08a5a, 1);
  const frameMat = new THREE.MeshStandardMaterial({ color: 0xf2efe8, roughness: 0.6, metalness: 0 });
  const glassMat = new THREE.MeshStandardMaterial({ color: 0x1d2a33, roughness: 0.15, metalness: 0.2 });

  const body = mesh(new THREE.BoxGeometry(W, H, D), wall, d);
  body.position.y = H / 2;
  group.add(body);
  const plinth = mesh(new THREE.BoxGeometry(W + 0.12, 0.45, D + 0.12), plinthMat, d);
  plinth.position.y = 0.225;
  group.add(plinth);

  // Door — centred on the front, 2.1 m, with a frame so it is a door and not a brown rectangle.
  const doorW = 1.0;
  const door = mesh(new THREE.BoxGeometry(doorW, 2.1, 0.08), woodMat, d);
  door.position.set(0, 0.45 + 1.05, D / 2 + 0.03);
  group.add(door);
  const doorFrame = mesh(new THREE.BoxGeometry(doorW + 0.2, 2.2, 0.05), frameMat, d);
  doorFrame.position.set(0, 0.45 + 1.1, D / 2 + 0.01);
  group.add(doorFrame);
  const step = mesh(new THREE.BoxGeometry(doorW + 0.6, 0.18, 0.5), plinthMat, d);
  step.position.set(0, 0.09, D / 2 + 0.3);
  group.add(step);

  // Windows: front (either side of the door, each storey) and both sides. Frame + glass + chhajja.
  const addWindow = (x: number, y: number, z: number, rotY: number) => {
    const win = new THREE.Group();
    const frame = mesh(new THREE.BoxGeometry(1.1, 1.2, 0.06), frameMat, d);
    win.add(frame);
    const glass = mesh(new THREE.BoxGeometry(0.92, 1.02, 0.07), glassMat, d);
    glass.position.z = 0.01;
    win.add(glass);
    const bar = mesh(new THREE.BoxGeometry(0.05, 1.02, 0.08), frameMat, d);
    bar.position.z = 0.02;
    win.add(bar);
    // The chhajja — the concrete sun-shade over every Indian window. It is what throws the shadow line.
    const shade = mesh(new THREE.BoxGeometry(1.4, 0.07, 0.45), concreteMat, d);
    shade.position.set(0, 0.72, 0.22);
    win.add(shade);
    win.position.set(x, y, z);
    win.rotation.y = rotY;
    group.add(win);
  };
  for (let s2 = 0; s2 < storeys; s2++) {
    const y = s2 * 3 + 1.75;
    const fx = Math.min(W / 2 - 0.9, doorW / 2 + 1.1);
    for (const side of [-1, 1]) {
      if (s2 > 0 || W > 4.5) addWindow(side * fx, y, D / 2 + 0.04, 0);
      addWindow(side * (W / 2 + 0.04), y, 0, side * Math.PI / 2);
    }
  }

  if (roofKind === 'flat') {
    // RCC slab overhang, a parapet you can see over the edge of, and the black Sintex-style tank.
    const slab = mesh(new THREE.BoxGeometry(W + 0.5, 0.18, D + 0.5), concreteMat, d);
    slab.position.y = H + 0.09;
    group.add(slab);
    const t = 0.15;
    for (const [w2, d2, x, z] of [[W, t, 0, D / 2 - t / 2], [W, t, 0, -D / 2 + t / 2], [t, D, W / 2 - t / 2, 0], [t, D, -W / 2 + t / 2, 0]] as const) {
      const parapet = mesh(new THREE.BoxGeometry(w2, 0.9, d2), wall, d);
      parapet.position.set(x, H + 0.18 + 0.45, z);
      group.add(parapet);
    }
    const tank = mesh(new THREE.CylinderGeometry(0.55, 0.6, 1.1, d === 'real' ? 20 : 10), new THREE.MeshStandardMaterial({ color: 0x1b1c1e, roughness: 0.55, metalness: 0 }), d);
    tank.position.set(W / 2 - 1.1, H + 0.18 + 0.55, -D / 2 + 1.1);
    group.add(tank);
  } else {
    // Sloped clay tiles: two pitched planes with an overhang, terracotta, ridge along the width.
    const tileMat = shared('tile', d, 0xb5532f, 3);
    const pitch = 0.5;
    const run = D / 2 + 0.5;
    const len = run / Math.cos(pitch);
    for (const side of [-1, 1]) {
      const plane = mesh(new THREE.BoxGeometry(W + 0.8, 0.12, len), tileMat, d);
      // Centred so the slope crosses the wall line (|z| = D/2) exactly at the wall top and the ridge meets
      // the gable apex — the overhang then dips below the wall top instead of leaving a gap above it.
      plane.position.set(0, H + Math.tan(pitch) * (run / 2 - 0.5), side * run / 2);
      plane.rotation.x = side * pitch;
      group.add(plane);
    }
    // Gable ends so the roof is closed, not two boards balanced on a box.
    const gableShape = new THREE.Shape();
    gableShape.moveTo(-D / 2, 0); gableShape.lineTo(D / 2, 0); gableShape.lineTo(0, Math.tan(pitch) * (D / 2)); gableShape.closePath();
    for (const side of [-1, 1]) {
      const gable = mesh(new THREE.ShapeGeometry(gableShape), wall, d);
      gable.position.set(side * (W / 2), H, 0);
      gable.rotation.y = side * Math.PI / 2;
      group.add(gable);
    }
  }
  return group;
}

// ── ANIMAL ───────────────────────────────────────────────────────────────────────────────────────
export type AnimalKind = 'deer' | 'dog' | 'cow' | 'horse' | 'goat' | 'tiger';
export interface AnimalOptions extends BaseOpts { height?: number; color?: number; kind?: AnimalKind }
export interface Animal { root: THREE.Group; update: (dt: number, speed: number) => void }

/** Height to the top of the head, in metres, by kind. The built animal is scaled to land exactly on it. */
export const ANIMAL_HEIGHT: Readonly<Record<AnimalKind, number>> = { dog: 0.62, goat: 0.95, tiger: 1.05, deer: 1.25, cow: 1.5, horse: 1.75 };

/**
 * A rounded, tapered piece rising from y = 0 to y = len (r0 at the base, r1 at the tip).
 * 🔴 The end caps are capped at 45% of the length each: with round caps, a piece shorter than r0 + r1
 * folded back through itself and rendered as a flat disc (a dog's short thick neck did exactly that).
 */
function taperGeo(r0: number, r1: number, len: number, radial: number): THREE.BufferGeometry {
  const pts: THREE.Vector2[] = [];
  const cap = 4;
  const h0 = Math.min(r0, len * 0.45), h1 = Math.min(r1, len * 0.45);
  for (let i = 0; i <= cap; i++) {
    const a = -Math.PI / 2 + (i / cap) * (Math.PI / 2);
    pts.push(new THREE.Vector2(Math.cos(a) * r0, h0 + Math.sin(a) * h0));
  }
  for (let i = 0; i <= cap; i++) {
    const a = (i / cap) * (Math.PI / 2);
    pts.push(new THREE.Vector2(Math.cos(a) * r1, len - h1 + Math.sin(a) * h1));
  }
  pts[0].x = 0; pts[pts.length - 1].x = 0;
  return new THREE.LatheGeometry(pts, radial);
}

function ellipsoid(rx: number, ry: number, rz: number, d: Detail): THREE.BufferGeometry {
  const g = d === 'real' ? new THREE.SphereGeometry(1, 16, 12) : new THREE.SphereGeometry(1, 9, 6);
  g.scale(rx, ry, rz);
  return g;
}

/**
 * Anatomy per kind, in units of the animal's own height (the whole rig is scaled to ANIMAL_HEIGHT
 * afterwards). These numbers ARE the animal: a horse is a long neck carried high on long legs, a cow is
 * a deep barrel on short legs with its head forward, a deer is slender legs and a small head held up, a
 * dog is a short body, a snout and a tail that curls up.
 */
const ANATOMY = {
  horse: { bL: 0.9, bR: 0.165, bW: 0.78, bY: 0.6, legR: 0.03, neckL: 0.4, neckTilt: 0.62, neckR: 0.075, headL: 0.3, headR: 0.06, snout: 0.62, droop: 0.78, ear: 'up', tail: 'hair', mane: true, horns: 'none', antlers: false, hump: false, paw: false, stripes: false, beard: false },
  cow:   { bL: 0.95, bR: 0.2, bW: 0.86, bY: 0.62, legR: 0.046, neckL: 0.22, neckTilt: 1.0, neckR: 0.095, headL: 0.27, headR: 0.075, snout: 0.85, droop: 0.75, ear: 'side', tail: 'tuft', mane: false, horns: 'cow', antlers: false, hump: true, paw: false, stripes: false, beard: false },
  deer:  { bL: 0.72, bR: 0.12, bW: 0.74, bY: 0.6, legR: 0.022, neckL: 0.34, neckTilt: 0.42, neckR: 0.05, headL: 0.2, headR: 0.05, snout: 0.5, droop: 0.95, ear: 'big', tail: 'short', mane: false, horns: 'none', antlers: true, hump: false, paw: false, stripes: false, beard: false },
  dog:   { bL: 0.92, bR: 0.17, bW: 0.78, bY: 0.55, legR: 0.045, neckL: 0.26, neckTilt: 0.6, neckR: 0.1, headL: 0.36, headR: 0.12, snout: 0.45, droop: 0.6, ear: 'up', tail: 'curl', mane: false, horns: 'none', antlers: false, hump: false, paw: true, stripes: false, beard: false },
  // Thin legs under a light body, horns swept BACK, a beard and a flicking tail — never a small cow.
  goat:  { bL: 0.9, bR: 0.15, bW: 0.74, bY: 0.62, legR: 0.03, neckL: 0.28, neckTilt: 0.45, neckR: 0.06, headL: 0.25, headR: 0.068, snout: 0.55, droop: 0.9, ear: 'side', tail: 'flick', mane: false, horns: 'goat', antlers: false, hump: false, paw: false, stripes: false, beard: true },
  // The catalogue's own tell: the shoulders are the highest point, the tail is nearly the body's length,
  // the broad head is carried LOW and level, and the paws are large. A deer with stripes is not a tiger.
  tiger: { bL: 1.3, bR: 0.21, bW: 0.86, bY: 0.6, legR: 0.058, neckL: 0.18, neckTilt: 1.2, neckR: 0.14, headL: 0.3, headR: 0.15, snout: 0.62, droop: 0.25, ear: 'round', tail: 'long', mane: false, horns: 'none', antlers: false, hump: false, paw: true, stripes: true, beard: false },
} as const;

/**
 * A quadruped with real anatomy and a real GAIT.
 *
 * 🔒 SILHOUETTE, NOT BOXES (admin 2026-10-05, Phase 2). The body is a lathed barrel, deeper at the chest
 * than the rump; legs are tapered, thick at the shoulder and fine at the cannon, ending in hooves or paws;
 * the neck rises from the chest and the head tapers to a muzzle with eyes, ears and a dark nose. Each kind
 * carries what identifies it at a glance: a horse's mane and hair tail, an Indian cow's hump and horns, a
 * deer's antlers and white scut, a dog's snout and curled tail.
 *
 * The gait is the other half: a four-legged animal moves DIAGONAL pairs together (front-left with
 * rear-right). Move all four in phase and it reads as a toy being dragged.
 */
export function createAnimal(options: AnimalOptions = {}): Animal {
  const d = tier(options);
  const real = d === 'real';
  const kind = options.kind ?? 'deer';
  // 🔴 SIZE BY KIND. Every kind used to default to 1.4 m, so a dog stood as tall as a horse — the four
  // animals rendered as one animal four times. Real heights to the top of the head, roughly.
  const H = options.height ?? ANIMAL_HEIGHT[kind];
  const A = ANATOMY[kind] ?? ANATOMY.deer;
  const col = options.color ?? (kind === 'cow' ? 0xd8cfc2 : kind === 'dog' ? 0x9a6b3f : kind === 'tiger' ? 0xd2782a : kind === 'goat' ? 0x5a463a : 0x8a5f38);
  // The hide is the near-white PLASTER grain, so the tint IS the animal's colour. It used to be 'fabric',
  // whose own texture is blue-grey: multiplied by a tint it turned a white cow purple and browns black.
  const hide = shared('plaster', d, col, 3);
  const dark = new THREE.MeshStandardMaterial({ color: 0x2a211a, roughness: 0.8, metalness: 0 });
  const hair = new THREE.MeshStandardMaterial({ color: kind === 'horse' ? 0x2b1d14 : 0x3a2c22, roughness: 0.95, metalness: 0 });
  const radial = real ? 14 : 7;
  const root = new THREE.Group();
  const rig = new THREE.Group();   // built at unit height, then scaled so the head lands on H
  root.add(rig);
  const torso = new THREE.Group(); // body, neck and tail move together; the legs stay planted
  rig.add(torso);

  // Body: a barrel lathed along its length — rounded rump, deepest at the chest.
  const prof = [[0, -0.5], [0.55, -0.48], [0.86, -0.4], [0.95, -0.2], [0.93, 0], [0.98, 0.2], [1, 0.32], [0.82, 0.44], [0.45, 0.49], [0, 0.5]];
  const bodyGeo = new THREE.LatheGeometry(prof.map(([r, y]) => new THREE.Vector2(r * A.bR, y * A.bL)), radial + 4);
  bodyGeo.rotateX(Math.PI / 2);          // length along +Z, chest at the front
  bodyGeo.scale(A.bW, 1, 1);
  const body = mesh(bodyGeo, hide, d);
  body.position.y = A.bY;
  torso.add(body);
  if (A.hump) {
    // The zebu hump over the shoulders — the Indian cow's silhouette.
    const hump = mesh(ellipsoid(A.bR * 0.42, A.bR * 0.4, A.bR * 0.55, d), hide, d);
    hump.position.set(0, A.bY + A.bR * 0.82, A.bL * 0.3);
    torso.add(hump);
  }

  if (A.stripes) {
    // A tiger's stripes: dark bands over the back and flanks, following the barrel's own curve.
    const rAt = (f: number) => {
      for (let i = 1; i < prof.length; i++) {
        const [r1, y1] = prof[i], [r0, y0] = prof[i - 1];
        if (f <= y1) return (r0 + ((f - y0) / Math.max(1e-6, y1 - y0)) * (r1 - r0)) * A.bR;
      }
      return A.bR;
    };
    const bands: THREE.Mesh[] = [];
    for (let i = 0; i < 8; i++) {
      const f = -0.38 + i * 0.1;
      const rr = rAt(f) * 1.015;
      const geo = new THREE.CylinderGeometry(rr, rr, A.bL * 0.035, 14, 1, true, Math.PI / 2 + 0.25, Math.PI - 0.5);
      geo.rotateX(Math.PI / 2);
      geo.scale(A.bW, 1, 1);
      const band = new THREE.Mesh(geo);
      band.position.set(0, A.bY, f * A.bL);
      band.rotation.z = (i % 2 ? 1 : -1) * 0.08;
      bands.push(band);
    }
    const stripeMat = new THREE.MeshStandardMaterial({ color: 0x1a1410, roughness: 0.9, side: THREE.DoubleSide });
    torso.add(mesh(mergeGeometries(bands), stripeMat, d));
  }

  // Neck: rises from the top of the chest, leaning forward by neckTilt.
  const neck = new THREE.Group();
  neck.position.set(0, A.bY + A.bR * 0.45, A.bL * 0.38);
  neck.rotation.x = A.neckTilt;
  torso.add(neck);
  const neckMesh = mesh(taperGeo(A.neckR * 1.35, A.neckR, A.neckL, radial), hide, d);
  neckMesh.scale.x = 0.8;
  neck.add(neckMesh);
  if (A.mane) {
    const mane = mesh(taperGeo(A.neckR * 0.5, A.neckR * 0.35, A.neckL * 1.02, radial), hair, d);
    mane.scale.set(0.35, 1, 1);
    mane.position.z = -A.neckR * 0.75;
    neck.add(mane);
  }

  // Head: tapers from the cranium to the muzzle, carried forward and tipped down by droop.
  const head = new THREE.Group();
  head.position.y = A.neckL;
  head.rotation.x = A.droop - A.neckTilt;
  neck.add(head);
  const headGeo = taperGeo(A.headR, A.headR * A.snout, A.headL, radial);
  headGeo.rotateX(Math.PI / 2);           // its length along +Z
  headGeo.translate(0, 0, -A.headR * 0.7);
  // The head's parts are baked into one mesh per material — a head of eight pieces is one draw call
  // for the hide, one for the dark nose and eyes, one for horns or antlers.
  const part = (geo: THREE.BufferGeometry) => new THREE.Mesh(geo);
  const headMesh = part(headGeo);
  headMesh.scale.set(0.82, 1, 1);
  const hideParts: THREE.Mesh[] = [headMesh];
  const darkParts: THREE.Mesh[] = [];
  const hornParts: THREE.Mesh[] = [];
  const tipZ = A.headL - A.headR * 0.7;
  const nose = part(ellipsoid(A.headR * A.snout * 0.75, A.headR * A.snout * 0.6, A.headR * 0.25, d));
  nose.position.set(0, 0, tipZ - A.headR * 0.12);
  darkParts.push(nose);
  for (const side of [-1, 1]) {
    if (real) {
      const eye = part(ellipsoid(A.headR * 0.16, A.headR * 0.16, A.headR * 0.12, d));
      eye.position.set(side * A.headR * 0.68, A.headR * 0.35, A.headR * 0.15);
      darkParts.push(eye);
    }
    // Ears: upright and pointed (horse, dog), big and spread (deer), out to the side (cow).
    const earLen = A.ear === 'big' ? A.headR * 1.7 : A.ear === 'side' ? A.headR * 1.0 : A.ear === 'round' ? A.headR * 0.5 : A.headR * 0.95;
    const ear = part(taperGeo(A.headR * 0.28, A.headR * 0.06, earLen, real ? 8 : 5));
    ear.scale.z = 0.45;
    ear.position.set(side * A.headR * 0.5, A.headR * 0.65, -A.headR * 0.35);
    ear.rotation.z = -side * (A.ear === 'side' ? 1.35 : A.ear === 'big' ? 0.75 : A.ear === 'round' ? 0.4 : 0.25);
    hideParts.push(ear);
    if (A.horns !== 'none') {
      // A cow's horns rise and spread; a goat's sweep straight back over its neck.
      const goat = A.horns === 'goat';
      const horn = part(taperGeo(A.headR * (goat ? 0.2 : 0.22), A.headR * 0.05, A.headR * (goat ? 1.6 : 1.3), real ? 8 : 5));
      horn.position.set(side * A.headR * (goat ? 0.3 : 0.45), A.headR * 0.8, -A.headR * (goat ? 0.3 : 0.45));
      horn.rotation.set(goat ? -1.15 : -0.35, 0, -side * (goat ? 0.18 : 0.55));
      hornParts.push(horn);
    }
    if (A.antlers) {
      // A main beam sweeping up and back, with two tines off it (posed in the beam's frame, then
      // carried into the head's frame so the whole rack bakes into one mesh).
      const beam = part(taperGeo(A.headR * 0.18, A.headR * 0.09, A.headR * 4, real ? 6 : 4));
      beam.position.set(side * A.headR * 0.4, A.headR * 0.8, -A.headR * 0.4);
      beam.rotation.set(-0.45, 0, -side * 0.45);
      beam.updateMatrix();
      hornParts.push(beam);
      for (const [at, tilt] of [[0.35, 0.9], [0.7, 0.7]]) {
        const tine = part(taperGeo(A.headR * 0.12, A.headR * 0.05, A.headR * 1.6, real ? 6 : 4));
        tine.position.y = A.headR * 4 * at;
        tine.rotation.x = tilt;
        tine.updateMatrix();
        tine.matrix.premultiply(beam.matrix);
        tine.matrix.decompose(tine.position, tine.quaternion, tine.scale);
        hornParts.push(tine);
      }
    }
  }
  if (A.beard) {
    const beard = part(taperGeo(A.headR * 0.22, A.headR * 0.05, A.headR * 0.9, real ? 6 : 4));
    beard.position.set(0, -A.headR * 0.55, tipZ - A.headR * 0.75);
    beard.rotation.x = Math.PI - 0.15;
    darkParts.push(beard);
  }
  head.add(mesh(mergeGeometries(hideParts), hide, d));
  head.add(mesh(mergeGeometries(darkParts), dark, d));
  if (hornParts.length) {
    const hornColor = A.antlers ? 0x6b5338 : 0xcfc3a8;
    head.add(mesh(mergeGeometries(hornParts), new THREE.MeshStandardMaterial({ color: hornColor, roughness: 0.7 }), d));
  }

  // Legs: tapered, thick at the top, fine at the cannon, ending in a hoof or a paw.
  const hipY = A.bY - A.bR * 0.25;
  const footH = A.paw ? A.legR * 1.2 : A.legR * 1.6;
  const upperL = (hipY - footH) * 0.52;
  const lowerL = hipY - footH - upperL;
  const legs: Array<{ hip: THREE.Group; knee: THREE.Group }> = [];
  for (const sz of [1, -1]) {
    for (const sx of [-1, 1]) {
      const hip = new THREE.Group();
      // Inside the barrel's footprint: the top of a leg belongs to the body, it is not bolted beside it.
      hip.position.set(sx * A.bR * A.bW * 0.45, hipY, sz * A.bL * 0.33);
      rig.add(hip);
      const thick = sz < 0 ? 1.6 : 1.35;   // the hindquarters carry the bigger muscle
      const upper = mesh(taperGeo(A.legR * thick, A.legR * 1.05, upperL + A.legR, radial), hide, d);
      upper.rotation.x = Math.PI;          // hangs down from the hip
      upper.position.y = A.legR;
      hip.add(upper);
      const knee = new THREE.Group();
      knee.position.y = -upperL;
      hip.add(knee);
      const lower = mesh(taperGeo(A.legR * 1.0, A.legR * 0.8, lowerL + A.legR * 0.5, radial), hide, d);
      lower.rotation.x = Math.PI;
      lower.position.y = A.legR * 0.5;
      knee.add(lower);
      const foot = A.paw
        ? mesh(ellipsoid(A.legR * 1.15, footH * 0.55, A.legR * 1.6, d), hide, d)
        : mesh(new THREE.CylinderGeometry(A.legR * 0.95, A.legR * 1.2, footH, radial), dark, d);
      foot.position.set(0, -lowerL - footH * 0.5, A.paw ? A.legR * 0.5 : 0);
      knee.add(foot);
      legs.push({ hip, knee });
    }
  }

  // Tail: a long hair tail (horse), a thin tail with a tuft (cow), a white scut (deer), a curl (dog).
  const tail = new THREE.Group();
  tail.position.set(0, A.bY + A.bR * 0.55, -A.bL * 0.47);
  torso.add(tail);
  if (A.tail === 'hair') {
    const t = mesh(taperGeo(A.legR * 1.4, A.legR * 0.6, A.bY * 0.75, radial), hair, d);
    t.rotation.x = Math.PI + 0.3;      // down and BACK, away from the rump
    tail.add(t);
  } else if (A.tail === 'tuft') {
    const len = A.bY * 0.7, lean = 0.12;
    const t = mesh(taperGeo(A.legR * 0.45, A.legR * 0.35, len, real ? 6 : 4), hide, d);
    t.rotation.x = Math.PI + lean;
    tail.add(t);
    // The tuft sits ON the tail's tip, wherever the lean puts it.
    const tuft = mesh(ellipsoid(A.legR * 0.7, A.legR * 2.2, A.legR * 0.7, d), hair, d);
    tuft.position.set(0, -Math.cos(lean) * len, -Math.sin(lean) * len);
    tail.add(tuft);
  } else if (A.tail === 'long') {
    // Nearly the body's length, heavy at the root, hanging back and lifting at the tip.
    const t = mesh(taperGeo(A.legR * 0.75, A.legR * 0.45, A.bL * 0.82, radial), hide, d);
    t.rotation.x = Math.PI + 1.05;
    tail.add(t);
  } else if (A.tail === 'flick') {
    const t = mesh(taperGeo(A.legR * 0.7, A.legR * 0.3, A.bR * 0.6, real ? 6 : 4), hide, d);
    t.rotation.x = -0.5;
    tail.add(t);
  } else if (A.tail === 'short') {
    const t = mesh(ellipsoid(A.bR * 0.25, A.bR * 0.4, A.bR * 0.18, d), new THREE.MeshStandardMaterial({ color: 0xece6da, roughness: 0.9 }), d);
    t.position.z = -A.bR * 0.05;
    tail.add(t);
  } else {
    const t = mesh(taperGeo(A.legR * 0.9, A.legR * 0.45, A.bL * 0.38, radial), hide, d);
    t.rotation.x = -0.6;                 // up and back: a dog's tail is carried, not dragged
    tail.add(t);
  }

  let phase = 0;
  const update = (dt: number, speed: number) => {
    const moving = speed > 0.05;
    phase += dt * (moving ? Math.min(2.5 + speed * 1.1, 11) : 1.6);
    const swing = moving ? Math.min(0.3 + speed * 0.05, 0.75) : 0.03;
    // DIAGONAL PAIRS: legs 0 (front-left) and 3 (rear-right) share a phase.
    const pair = [0, 1, 1, 0];
    for (let i = 0; i < legs.length; i++) {
      const s = Math.sin(phase + pair[i] * Math.PI);
      legs[i].hip.rotation.x = s * swing;
      legs[i].knee.rotation.x = Math.max(0, -s * swing * 1.3);
    }
    torso.position.y = moving ? Math.abs(Math.sin(phase * 2)) * 0.012 : 0;
    neck.rotation.x = A.neckTilt + (moving ? 0.05 + swing * 0.1 : Math.sin(phase * 0.5) * 0.04);
    tail.rotation.x = Math.sin(phase * 0.8) * 0.14;
  };
  update(0, 0);
  // Land the top of the head on H exactly, whatever the anatomy table adds up to.
  rig.updateMatrixWorld(true);
  const top = new THREE.Box3().setFromObject(rig).max.y;
  rig.scale.setScalar(H / (top > 0 ? top : 1));
  return { root, update };
}

// ── MOTORCYCLE ───────────────────────────────────────────────────────────────────────────────────
export interface MotorcycleOptions extends BaseOpts { color?: number; length?: number; kind?: 'sport' | 'commuter' | 'cruiser' }
export interface Motorcycle {
  root: THREE.Group;
  /** Attach a rider here — createHumanoid().root goes straight in, already seated and facing forward. */
  seat: THREE.Object3D;
  /** Lean into a corner (radians, + is right). A bike that corners flat reads as a prop on rails. */
  lean: (radians: number) => void;
  /** Turn the bars (radians). Moves the forks, wheel, mudguard and headlight together, as one assembly. */
  steer: (radians: number) => void;
  /** Spin the wheels from speed in m/s. Still wheels under a moving bike is the oldest tell there is. */
  roll: (speed: number, dt: number) => void;
}

/**
 * A motorcycle at real proportions: 2.05 m long, 1.35 m WHEELBASE, 0.30 m wheel radius, 0.80 m seat
 * height, 0.72 m across the bars. Those five numbers are most of why it reads as a bike.
 *
 * 🔴 THE ONE THING THAT DECIDES IT, AND THE ONE EVERY IMPROVISED BIKE GETS WRONG: a motorcycle is
 * mostly AIR. The wheels sit far apart with an open gap beneath the engine, the tank-to-tail line
 * falls backwards, and the forks are RAKED — not vertical. A body blob bridging two cylinders has
 * none of those, which is precisely why it reads as a toy however good the lighting is.
 *
 * `real` adds what you only notice up close and miss instantly when it is gone: a separate tyre and
 * rim with spokes, a front disc and caliper, the swingarm and chain run, an exhaust that leaves the
 * engine and ends in a can, mudguards over both wheels, mirrors, footpegs, and a headlight and tail
 * light that actually EMIT.
 */
export function createMotorcycle(options: MotorcycleOptions = {}): Motorcycle {
  const d = tier(options);
  const L = options.length ?? 2.05;
  const kind = options.kind ?? 'sport';
  const paint = options.color ?? 0xc4231f;

  const wheelR = L * 0.146;                                  // ~0.30 m — a 17" rim plus tyre
  const base = L * (kind === 'cruiser' ? 0.7 : 0.659);       // wheelbase: a cruiser is longer
  const seatY = L * (kind === 'cruiser' ? 0.34 : 0.39);      // ~0.80 m; cruisers sit lower
  const barW = L * 0.35;                                     // ~0.72 m across the grips
  const rake = kind === 'cruiser' ? 0.56 : kind === 'commuter' ? 0.44 : 0.46;  // fork angle, radians

  const root = new THREE.Group();

  const paintMat = d === 'real'
    ? new THREE.MeshPhysicalMaterial({ color: paint, roughness: 0.24, metalness: 0.8, clearcoat: 1, clearcoatRoughness: 0.07 })
    : new THREE.MeshStandardMaterial({ color: paint, roughness: 0.5, metalness: 0.3 });
  const chrome = new THREE.MeshStandardMaterial({ color: 0xcfd6de, roughness: 0.18, metalness: 1 });
  const engineMat = new THREE.MeshStandardMaterial({ color: 0x3b4046, roughness: 0.45, metalness: 0.9 });
  const matte = new THREE.MeshStandardMaterial({ color: 0x1b1e22, roughness: 0.72, metalness: 0.25 });
  const tyreMat = shared('fabric', d, 0x121418, 2);
  const seatMat = shared('fabric', d, 0x15171a, 2);
  const seg = d === 'real' ? 22 : 10;

  /** One wheel, as a GROUP so it can be rolled and steered independently of the frame. */
  const makeWheel = (radius: number, width: number): THREE.Group => {
    const w = new THREE.Group();
    const tyre = mesh(new THREE.TorusGeometry(radius * 0.86, radius * 0.15, d === 'real' ? 10 : 6, seg), tyreMat, d);
    tyre.rotation.y = Math.PI / 2;
    w.add(tyre);
    if (d === 'real') {
      const rim = mesh(new THREE.CylinderGeometry(radius * 0.72, radius * 0.72, width, seg), chrome, d);
      rim.rotation.z = Math.PI / 2;
      w.add(rim);
      // Spokes: five, because the gaps are what stop a wheel reading as a solid disc.
      for (let i = 0; i < 5; i++) {
        const spoke = mesh(new THREE.BoxGeometry(width * 0.6, radius * 1.34, radius * 0.09), chrome, d);
        spoke.rotation.x = (i * Math.PI) / 5;
        w.add(spoke);
      }
      const hub = mesh(new THREE.CylinderGeometry(radius * 0.2, radius * 0.2, width * 1.25, 10), engineMat, d);
      hub.rotation.z = Math.PI / 2;
      w.add(hub);
    } else {
      const disc = mesh(new THREE.CylinderGeometry(radius * 0.7, radius * 0.7, width * 0.9, seg), matte, d);
      disc.rotation.z = Math.PI / 2;
      w.add(disc);
    }
    w.name = 'wheel';
    return w;
  };

  // ── REAR: wheel, swingarm and the chain run ───────────────────────────────────────────────────
  const rearWheel = makeWheel(wheelR, L * 0.075);
  rearWheel.position.set(0, wheelR, -base / 2);
  root.add(rearWheel);

  if (d === 'real') {
    for (const side of [-1, 1]) {
      const arm = mesh(new THREE.BoxGeometry(L * 0.022, L * 0.038, base * 0.42), matte, d);
      arm.position.set(side * L * 0.048, wheelR * 1.02, -base * 0.29);
      arm.rotation.x = 0.06;
      root.add(arm);
    }
    const sprocket = mesh(new THREE.CylinderGeometry(wheelR * 0.34, wheelR * 0.34, L * 0.012, 14), chrome, d);
    sprocket.rotation.z = Math.PI / 2;
    sprocket.position.set(L * 0.055, wheelR, -base / 2);
    root.add(sprocket);
    const chain = mesh(new THREE.BoxGeometry(L * 0.008, wheelR * 0.5, base * 0.34), matte, d);
    chain.position.set(L * 0.055, wheelR * 1.05, -base * 0.33);
    root.add(chain);
    // Rear shock, visibly angled — a vertical strut looks like scaffolding.
    const shock = mesh(new THREE.CylinderGeometry(L * 0.014, L * 0.014, L * 0.17, 8), chrome, d);
    shock.position.set(0, wheelR * 1.75, -base * 0.2);
    shock.rotation.x = -0.4;
    root.add(shock);
  }

  // ── ENGINE: the mass low and CENTRAL, with daylight under it ───────────────────────────────────
  const engine = mesh(new THREE.BoxGeometry(L * 0.17, L * 0.16, L * 0.2), engineMat, d);
  engine.position.set(0, wheelR * 1.15, -L * 0.02);
  root.add(engine);
  if (d === 'real') {
    // Cooling fins: three thin plates. Nothing says "engine" faster at this scale.
    for (let i = 0; i < 3; i++) {
      const fin = mesh(new THREE.BoxGeometry(L * 0.19, L * 0.012, L * 0.19), chrome, d);
      fin.position.set(0, wheelR * 1.15 + (i - 1) * L * 0.042, -L * 0.02);
      root.add(fin);
    }
    // Exhaust: header out of the engine, then a can along the right side, rising slightly.
    const header = mesh(new THREE.CylinderGeometry(L * 0.017, L * 0.017, L * 0.3, 10), chrome, d);
    header.position.set(L * 0.05, wheelR * 0.8, L * 0.05);
    header.rotation.set(Math.PI / 2 - 0.25, 0, 0.18);
    root.add(header);
    const can = mesh(new THREE.CylinderGeometry(L * 0.033, L * 0.028, L * 0.36, 12), chrome, d);
    can.position.set(L * 0.075, wheelR * 1.15, -L * 0.24);
    can.rotation.set(Math.PI / 2 - 0.12, 0, 0.1);
    root.add(can);
    for (const side of [-1, 1]) {
      const peg = mesh(new THREE.CylinderGeometry(L * 0.009, L * 0.009, L * 0.05, 6), chrome, d);
      peg.position.set(side * L * 0.085, wheelR * 0.72, -L * 0.06);
      peg.rotation.z = Math.PI / 2;
      root.add(peg);
    }
  }

  // ── FRAME: a spine from the steering head down to the swingarm pivot ───────────────────────────
  const spine = mesh(new THREE.BoxGeometry(L * 0.05, L * 0.05, base * 0.5), matte, d);
  spine.position.set(0, seatY * 0.92, L * 0.06);
  spine.rotation.x = 0.2;
  root.add(spine);

  // ── TANK: the single most bike-defining shape. Widest at the knees, tapering to the seat ───────
  const tank = mesh(new THREE.BoxGeometry(L * 0.19, L * 0.14, L * 0.3), paintMat, d);
  tank.position.set(0, seatY * 1.02, L * 0.12);
  tank.rotation.x = -0.07;
  root.add(tank);
  if (d === 'real') {
    const tankNose = mesh(new THREE.BoxGeometry(L * 0.13, L * 0.1, L * 0.12), paintMat, d);
    tankNose.position.set(0, seatY * 1.04, L * 0.28);
    tankNose.rotation.x = -0.22;
    root.add(tankNose);
    const cap = mesh(new THREE.CylinderGeometry(L * 0.026, L * 0.026, L * 0.012, 12), chrome, d);
    cap.position.set(0, seatY * 1.11, L * 0.14);
    root.add(cap);
  }

  // ── SEAT + TAIL: the line that FALLS toward the back. Flat here and the bike reads as a bench ──
  const seatMesh = mesh(new THREE.BoxGeometry(L * 0.13, L * 0.05, L * 0.3), seatMat, d);
  seatMesh.position.set(0, seatY, -L * 0.11);
  seatMesh.rotation.x = kind === 'cruiser' ? 0.02 : -0.06;
  root.add(seatMesh);
  const tail = mesh(new THREE.BoxGeometry(L * 0.1, L * 0.07, L * 0.18), paintMat, d);
  tail.position.set(0, seatY * 1.06, -L * 0.29);
  tail.rotation.x = kind === 'sport' ? -0.3 : -0.12;   // a sport tail kicks UP; that is its signature
  root.add(tail);

  // The rider's anchor: at the seat, facing -Z like the bike. Empty until a game puts someone on it.
  const seatAnchor = new THREE.Object3D();
  seatAnchor.position.set(0, seatY, -L * 0.08);
  seatAnchor.name = 'seat';
  root.add(seatAnchor);

  // ── FRONT: ONE steering group, so bars, forks, wheel, mudguard and light turn TOGETHER ─────────
  //
  // 🔴 THE RAKE HAS TO BE PAID FOR, OR THE WHEELBASE IS NOT THE WHEELBASE. A raked fork carries its
  // wheel FORWARD of the steering head by sin(rake) x forkLen — about 0.32 m on this bike. Hang the
  // forks off a head placed at base/2 and the real wheelbase comes out ~1.62 m instead of 1.35: a
  // stretched, chopper-ish machine that is not what anyone asked for, and nothing in the render says
  // so. The head is therefore set BACK by exactly that offset, and the arithmetic below is what makes
  // the five numbers in the doc comment true rather than aspirational.
  const headY = seatY * 1.15;                              // steering-head height
  const forkLen = (headY - wheelR) / Math.cos(rake);        // reach the ground AT the rake, not beside it
  const frontZ = Math.sin(rake) * forkLen;                  // how far the rake throws the wheel forward
  const steerGroup = new THREE.Group();
  steerGroup.position.set(0, headY, base / 2 - frontZ);
  steerGroup.name = 'steer';
  root.add(steerGroup);

  // Forks are RAKED. Vertical forks are the second-clearest sign of an improvised bike.
  // NEGATIVE rotation.x, because a rotation about +X swings -Y toward -Z: the positive sign would
  // rake the forks BACKWARDS, under the engine.
  for (const side of [-1, 1]) {
    const fork = mesh(new THREE.CylinderGeometry(L * 0.017, L * 0.019, forkLen, d === 'real' ? 10 : 6), chrome, d);
    fork.position.set(side * L * 0.048, (-forkLen / 2) * Math.cos(rake), (forkLen / 2) * Math.sin(rake));
    fork.rotation.x = -rake;
    steerGroup.add(fork);
  }
  const frontWheel = makeWheel(wheelR * 0.98, L * 0.055);
  frontWheel.position.set(0, -(headY - wheelR), frontZ);
  steerGroup.add(frontWheel);

  const bar = mesh(new THREE.CylinderGeometry(L * 0.012, L * 0.012, barW, 8), matte, d);
  bar.rotation.z = Math.PI / 2;
  bar.position.set(0, L * 0.03, 0);
  steerGroup.add(bar);

  if (d === 'real') {
    const clamp = mesh(new THREE.BoxGeometry(L * 0.13, L * 0.025, L * 0.05), matte, d);
    clamp.position.set(0, L * 0.01, L * 0.01);
    steerGroup.add(clamp);
    for (const side of [-1, 1]) {
      const grip = mesh(new THREE.CylinderGeometry(L * 0.017, L * 0.017, L * 0.055, 8), matte, d);
      grip.rotation.z = Math.PI / 2;
      grip.position.set(side * (barW / 2 - L * 0.03), L * 0.03, 0);
      steerGroup.add(grip);
      const mirror = mesh(new THREE.BoxGeometry(L * 0.035, L * 0.022, L * 0.012), matte, d);
      mirror.position.set(side * (barW / 2 - L * 0.02), L * 0.08, -L * 0.01);
      steerGroup.add(mirror);
    }
    // Front disc + caliper. A brakeless front wheel is a detail people feel without naming.
    const disc = mesh(new THREE.CylinderGeometry(wheelR * 0.55, wheelR * 0.55, L * 0.006, 18), chrome, d);
    disc.rotation.z = Math.PI / 2;
    disc.position.copy(frontWheel.position);
    disc.position.x = L * 0.04;
    steerGroup.add(disc);
    const caliper = mesh(new THREE.BoxGeometry(L * 0.016, L * 0.05, L * 0.035), matte, d);
    caliper.position.set(L * 0.04, frontWheel.position.y + wheelR * 0.55, frontWheel.position.z - L * 0.02);
    steerGroup.add(caliper);
    // Mudguard hugging the tyre — a wheel with clear sky above it looks unfinished.
    const guard = mesh(new THREE.BoxGeometry(L * 0.075, L * 0.014, wheelR * 1.5), paintMat, d);
    guard.position.set(0, frontWheel.position.y + wheelR * 0.95, frontWheel.position.z);
    steerGroup.add(guard);
  }

  // Lights that EMIT. An unlit "light" is a coloured sticker, on a bike as much as on a car.
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(L * 0.045, 12, 10),
    new THREE.MeshBasicMaterial({ color: 0xfff4d2 }),
  );
  head.position.set(0, -L * 0.01, L * 0.06);
  head.scale.set(1, 0.85, 0.55);
  steerGroup.add(head);
  const tailLight = new THREE.Mesh(
    new THREE.BoxGeometry(L * 0.055, L * 0.022, L * 0.012),
    new THREE.MeshBasicMaterial({ color: 0xe02a1c }),
  );
  tailLight.position.set(0, seatY * 1.08, -L * 0.375);
  root.add(tailLight);

  const wheels: THREE.Group[] = [rearWheel, frontWheel];
  return {
    root,
    seat: seatAnchor,
    lean: (radians: number) => { root.rotation.z = radians; },
    steer: (radians: number) => { steerGroup.rotation.y = radians; },
    roll: (speed: number, dt: number) => {
      const spin = (speed * dt) / wheelR;
      for (const w of wheels) w.rotation.x -= spin;
    },
  };
}

// ── BICYCLE ──────────────────────────────────────────────────────────────────────────────────────
export interface BicycleOptions extends BaseOpts { color?: number; length?: number }

/**
 * A pedal cycle — 1.75 m long, 1.05 m wheelbase, 0.34 m wheel radius, and a DIAMOND frame.
 *
 * It is not a small motorcycle: the frame is open tubing you can see through, the wheels are larger
 * and far thinner, and there is no engine mass in the middle. Building it as a shrunken motorbike is
 * why most generated cycles look wrong.
 */
export function createBicycle(options: BicycleOptions = {}): Motorcycle {
  const d = tier(options);
  const L = options.length ?? 1.75;
  const wheelR = L * 0.194;
  const base = L * 0.6;
  const seatY = L * 0.55;
  const frameMat = new THREE.MeshStandardMaterial({ color: options.color ?? 0x1e88d6, roughness: 0.32, metalness: 0.7 });
  const matte2 = new THREE.MeshStandardMaterial({ color: 0x1b1e22, roughness: 0.75, metalness: 0.2 });
  const chrome2 = new THREE.MeshStandardMaterial({ color: 0xcfd6de, roughness: 0.2, metalness: 1 });
  const tyre2 = shared('fabric', d, 0x14161a, 2);
  const root = new THREE.Group();
  const seg2 = d === 'real' ? 20 : 10;

  const makeThinWheel = (): THREE.Group => {
    const w = new THREE.Group();
    const t = mesh(new THREE.TorusGeometry(wheelR * 0.9, wheelR * 0.07, 8, seg2), tyre2, d);
    t.rotation.y = Math.PI / 2;
    w.add(t);
    if (d === 'real') {
      for (let i = 0; i < 6; i++) {
        const spoke = mesh(new THREE.BoxGeometry(L * 0.004, wheelR * 1.7, L * 0.004), chrome2, d);
        spoke.rotation.x = (i * Math.PI) / 6;
        w.add(spoke);
      }
    }
    w.name = 'wheel';
    return w;
  };

  const rear = makeThinWheel(); rear.position.set(0, wheelR, -base / 2); root.add(rear);

  const tube = (len: number, x: number, y: number, z: number, rx: number): void => {
    const t = mesh(new THREE.CylinderGeometry(L * 0.013, L * 0.013, len, 8), frameMat, d);
    t.position.set(x, y, z); t.rotation.x = rx; root.add(t);
  };
  tube(base * 0.62, 0, seatY * 0.82, L * 0.02, Math.PI / 2 - 0.16);   // top tube
  tube(base * 0.6, 0, seatY * 0.5, L * 0.02, Math.PI / 2 + 0.1);       // down tube
  tube(seatY * 0.6, 0, seatY * 0.62, -L * 0.13, 0.25);                 // seat tube
  tube(base * 0.42, 0, wheelR * 1.05, -L * 0.16, Math.PI / 2 - 0.06);  // chain stay

  const saddle = mesh(new THREE.BoxGeometry(L * 0.055, L * 0.025, L * 0.13), matte2, d);
  saddle.position.set(0, seatY, -L * 0.14);
  root.add(saddle);
  const seatAnchor = new THREE.Object3D();
  seatAnchor.position.set(0, seatY, -L * 0.12);
  seatAnchor.name = 'seat';
  root.add(seatAnchor);

  if (d === 'real') {
    const crank = mesh(new THREE.CylinderGeometry(wheelR * 0.28, wheelR * 0.28, L * 0.01, 14), chrome2, d);
    crank.rotation.z = Math.PI / 2;
    crank.position.set(0, wheelR * 1.0, -L * 0.02);
    root.add(crank);
    for (const side of [-1, 1]) {
      const pedal = mesh(new THREE.BoxGeometry(L * 0.03, L * 0.012, L * 0.06), matte2, d);
      pedal.position.set(side * L * 0.055, wheelR * 0.78, -L * 0.02);
      root.add(pedal);
    }
  }

  // Same rake arithmetic as the motorcycle — a cycle's fork is raked too, and the wheelbase has to
  // survive it. See the comment there for why the offset is subtracted rather than guessed.
  const rake2 = 0.3;
  const headY2 = seatY * 1.05;
  const forkLen2 = (headY2 - wheelR) / Math.cos(rake2);
  const frontZ2 = Math.sin(rake2) * forkLen2;
  const steerGroup = new THREE.Group();
  steerGroup.position.set(0, headY2, base / 2 - frontZ2);
  steerGroup.name = 'steer';
  root.add(steerGroup);
  for (const side of [-1, 1]) {
    const fork = mesh(new THREE.CylinderGeometry(L * 0.009, L * 0.009, forkLen2, 6), frameMat, d);
    fork.position.set(side * L * 0.03, (-forkLen2 / 2) * Math.cos(rake2), (forkLen2 / 2) * Math.sin(rake2));
    fork.rotation.x = -rake2;
    steerGroup.add(fork);
  }
  const front = makeThinWheel();
  front.position.set(0, -(headY2 - wheelR), frontZ2);
  steerGroup.add(front);
  const bars = mesh(new THREE.CylinderGeometry(L * 0.01, L * 0.01, L * 0.32, 8), matte2, d);
  bars.rotation.z = Math.PI / 2;
  steerGroup.add(bars);

  const wheels2: THREE.Group[] = [rear, front];
  return {
    root,
    seat: seatAnchor,
    lean: (radians: number) => { root.rotation.z = radians; },
    steer: (radians: number) => { steerGroup.rotation.y = radians; },
    roll: (speed: number, dt: number) => {
      const spin = (speed * dt) / wheelR;
      for (const w of wheels2) w.rotation.x -= spin;
    },
  };
}
